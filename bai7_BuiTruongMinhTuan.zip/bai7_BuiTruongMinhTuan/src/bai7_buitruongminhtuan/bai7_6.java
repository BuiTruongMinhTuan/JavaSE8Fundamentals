/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ktSoNGTo(nhapNam());
        
    }
    static int nhapNam() throws IOException {
        int so = 0;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao so kiem tra:");
        so = Integer.parseInt(input.readLine());
        return so;
    }
    static void ktSoNGTo(int so)
    {
        boolean soNguyenTo = false;
        if (so < 2) {
            System.out.println("ket qua la :" + so + "khong phai la so nguyen to");
        } else {
            for (int i = 2; i < so / 2; i++) {
                if (so % i == 0) {
                    soNguyenTo = !soNguyenTo;

                    break;
                }
            }

            if (soNguyenTo) {
                System.out.println("ket qua la :" + so + "khong la so nguyen to");
            } else {
                System.out.println("ket qua la :" + so + " la so nguyen to");
            }
        }
    }
    
}
