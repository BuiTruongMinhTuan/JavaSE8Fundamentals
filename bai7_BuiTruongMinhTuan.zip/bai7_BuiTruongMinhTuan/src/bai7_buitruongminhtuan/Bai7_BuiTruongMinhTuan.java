/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        float tich = 1;
        System.out.println("Nhap vao so lan lap n:");
        int n = Integer.parseInt(input.readLine());
        System.out.println("Nhap vao so x:");
        int x = Integer.parseInt(input.readLine());
        System.out.print("Cach viet thong thuong: S =(x*x+1)=");
        if (n == 0) {
            System.out.print(" " + tich);
        } else {
            for (int i = 1; i <= n; i++) {
                tich *= (x * x + 1);
            }
            System.out.print(" " + tich);
        }
        System.out.println("");
        System.out.print("Cach viet phuong thuc: S =(x*x+1)=");
        tinhTich(n, x);
        System.out.println("");
    }
    static void tinhTich(int n,int x)
    {
        float tich=1;
        if (n == 0) {
            System.out.print(" " + tich);
        } else {
            for (int i = 1; i <= n; i++) {
                tich *= (x * x + 1);
            }
            System.out.print(" " + tich);
        }
        
    }
    
}
