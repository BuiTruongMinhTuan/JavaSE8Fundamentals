/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai7_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        tinhTongNgauNhien(nhapNam());
    }
    static int[] nhapNam() throws IOException {
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao n thap phan cua mang:");
        int readNum = Integer.parseInt(input.readLine());
        int[] anArray = new int[readNum];
        return anArray;
    }
    static void tinhTongNgauNhien(int[] anArray)
    {
        int tong = 0;
        Random varRandom = new Random();
        for (int i = 0; i < anArray.length; i++) {
            anArray[i] = varRandom.nextInt(10);
            System.out.print(anArray[i] + " ");
            tong += anArray[i];
        }
        System.out.println("tong = " + tong);
    }
    
}
