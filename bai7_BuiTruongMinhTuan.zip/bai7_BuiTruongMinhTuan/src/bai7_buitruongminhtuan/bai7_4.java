
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int nam = nhapNam();
        String can = tinhCan(nam);
        String chi = tinhChi(nam);
        xuatNham(can, chi);
    }

    static int nhapNam() throws IOException {
        int nam = 0;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao so nam duong lich:");
        nam = Integer.parseInt(input.readLine());
        return nam;
    }
    static void xuatNham(String can,String chi)
    {
         System.out.println("nam am lich: "+can+" "+chi);
    }

    static String tinhCan(int nam) {
        String can = "";
        int tinhCan = nam % 10;
        switch (tinhCan) {
            case 0:
                can = "Canh";
                break;
            case 1:
                can = "Tan";
                break;
            case 2:
                can = "Nham";
                break;
            case 3:
                can = "Quy";
                break;
            case 4:
                can = "Giap";
                break;
            case 5:
                can = "At";
                break;
            case 6:
                can = "Binh";
                break;
            case 7:
                can = "Dinh";
                break;
            case 8:
                can = "Mau";
                break;
            case 9:
                can = "Ky";
                break;
        }
        return can;
    }

    static String tinhChi(int nam) {
        String chi = "";
        int tinhChi = nam % 12;
        switch (tinhChi) {
            case 0:
                chi = "Than";
                break;
            case 1:
                chi = "Dau";
                break;
            case 2:
                chi = "Tuat";
                break;
            case 3:
                chi = "Hoi";
                break;
            case 4:
                chi = "Ty";
                break;
            case 5:
                chi = "Suu";
                break;
            case 6:
                chi = "Dan";
                break;
            case 7:
                chi = "Mao";
                break;
            case 8:
                chi = "Thin";
                break;
            case 9:
                chi = "Ty";
                break;
            case 10:
                chi = "Ngo";
                break;
            case 11:
                chi = "Mui";
                break;
        }
        return chi;
    }

}
