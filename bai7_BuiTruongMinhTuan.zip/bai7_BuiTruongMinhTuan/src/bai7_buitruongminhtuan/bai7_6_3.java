/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_6_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        doiSoNTo(nhapNam());
    }
    static int nhapNam() throws IOException {
        int so = 0;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao so thap phan:");
        so = Integer.parseInt(input.readLine());
        return so;
    }
    static  void doiSoNTo(int soThapPhan)
    {
        String sTemp = "";
        
        for(;soThapPhan!=0;soThapPhan/=2)
        {
            sTemp+=soThapPhan%2;
        }
        String soNhiPhan=new StringBuffer(sTemp).reverse().toString();
        System.out.println("so thap phan: "+soNhiPhan);
    }
    
}
