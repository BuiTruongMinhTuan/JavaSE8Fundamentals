/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai7_9_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int[][]mangHaiChieu=tongCheo();
        ktNTo(mangHaiChieu);
        int[][]mangB=mangB(mangHaiChieu);
        mangC(mangHaiChieu, mangB);
        
        
    }
    static int[][] tongCheo() throws IOException
    {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so n so dong mang:");
        int soDong = Integer.parseInt(input.readLine());
        Random random = new Random();
        int[][] mangHaiChieu = new int[soDong][soDong];
        int tongCheo = 0;
        int maxCheo = 0;
        int minCheo = 0;

        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                mangHaiChieu[i][j] = random.nextInt(20);
                System.out.print(mangHaiChieu[i][j] + " ");
                if (i == 0 && j == 0) {
                    maxCheo = minCheo = mangHaiChieu[i][j];
                }
                if (i == j) {
                    tongCheo += mangHaiChieu[i][j];
                    maxCheo = Math.max(maxCheo, mangHaiChieu[i][j]);
                    minCheo = Math.min(minCheo, mangHaiChieu[i][j]);
                }

            }
            System.out.print("\n");
        }
        System.out.println("\nTong duong cheo:" + tongCheo);
        System.out.println("So nho nhat duong cheo:" + minCheo);
        System.out.println("So lon nhat duong cheo:" + maxCheo);
        return mangHaiChieu;
    }
    static void ktNTo(int[][]mangHaiChieu)
    {
        boolean soNgTo;
        for (int i = 0; i < mangHaiChieu.length; i++) {

            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                soNgTo = true;
                for (int k = 2; k < mangHaiChieu[i][j]; k++) {

                    if (mangHaiChieu[i][j] % k == 0) {
                        soNgTo = false;
                        break;
                    }
                }
                if (soNgTo && mangHaiChieu[i][j] > 1) {
                    System.out.print(mangHaiChieu[i][j] + " ");

                }

            }
        }
        System.out.print(" La so nguyen to\n");
    }
    static int[][] mangB(int[][]mangA) throws IOException
    {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int[][] mangB = new int[mangA.length][mangA.length];
        System.out.println("Nhap vao gia tri cua mangB:");

        for (int i = 0; i < mangB.length; i++) {
            for (int j = 0; j < mangB[i].length; j++) {
                System.out.println("vi tri:" + i + " " + j);
                mangB[i][j] = Integer.parseInt(input.readLine());
            }
        }
        System.out.println("gia tri cua mangB:");
        for (int i = 0; i < mangB.length; i++) {
            for (int j = 0; j < mangB[i].length; j++) {
                System.out.print(mangB[i][j] + " ");

            }
            System.out.print("\n");
        }
        boolean doiXung = true;
        for (int i = 0; i < mangB.length; i++) {
            for (int j = 0; j < mangB[i].length; j++) {
                if (mangB[i][j] != mangB[j][i]) {
                    doiXung = false;
                    break;
                }

            }
        }
        if (doiXung) {
            System.out.println("mangB doi xung qua duong cheo");
        } else {
            System.out.println("mangB khong doi xung qua duong cheo");
        }
        return mangB;
    }
    static void mangC(int[][]mangA,int[][]mangB) throws IOException
    {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int[][] mangC = new int[mangA.length][mangA.length];
        for (int i = 0; i < mangC.length; i++) {
            for (int j = 0; j < mangC[i].length; j++) {
                mangC[i][j] = mangA[i][j] + mangB[i][j];
            }
        }

        System.out.println("gia tri mangC: ");
        for (int i = 0; i < mangC.length; i++) {
            for (int j = 0; j < mangC[i].length; j++) {
                System.out.print(mangC[i][j] + " ");

            }
            System.out.print("\n");
        }
        boolean tangDan = false;
        boolean giamDan = false;
        System.out.println("nhap vao vi tri cot K (tu 0 den " + (mangA.length - 1)+")");
        int cotK = Integer.parseInt(input.readLine());
        for (int i = 0; i < mangC.length - 1; i++) {
            if (mangC[i][cotK] > mangC[i + 1][cotK]) {
                giamDan = false;
            } else {
                giamDan = true;
                break;
            }
        }
        for (int i = 0; i < mangC.length - 1; i++) {
            if (mangC[i][cotK] < mangC[i + 1][cotK]) {
                tangDan = false;
            } else {
                tangDan = true;
                break;
            }
        }
        if (giamDan) {
            System.out.println("cac phan tu trong cotK khong giam dan");
        } else {
            System.out.println("cac phan tu trong cotK  giam dan");
        }

        if (tangDan) {
            System.out.println("cac phan tu trong cotK khong tang  dan");
        } else {
            System.out.println("cac phan tu trong cotK  tang dan");
        }
         for (int i = 0; i < mangC.length; i++) {
             System.out.println(mangC[i][cotK]);
         }
    }
}
