/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_6_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        tinh(nhapNam());
    }
    static int nhapNam() throws IOException {
        int so = 0;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao so n:");
        so = Integer.parseInt(input.readLine());
        return so;
    }
    static void tinh(int n)
    {
        int A = 0;
        int B = 0;
        float C = 1;
        float D = 1;
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0) {
                B += i;
            } else {
                A += i;
            }
            C *= i;
            if (i % 3 == 0) {
                D *= i;
            }
        }

        System.out.println("tong cac so le nho hon hay bang n:" + A);
        System.out.println("tong cac so chan nho hon hay bang n:" + B);
        System.out.println("tich tu 1 den n:" + C);
        System.out.println("tich cac so chia het cho 3 nho hon hay bang n:" + D);
    }
    
}
