/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_8_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        doiSangNhiPhan(nhap());
    }

    static String nhap() throws IOException {
        String soNhiPhan = "";
        String sTemp = "";
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao so nhi phan:");
        sTemp = input.readLine();
        soNhiPhan = new StringBuffer(sTemp).reverse().toString();
        return soNhiPhan;
    }

    static void doiSangNhiPhan(String soNhiPhan) {
        int temp;
        int soThapPhan = 0;
        for (int i = 0; i < soNhiPhan.length(); i++) {
            
            temp = soNhiPhan.charAt(i);
            
            if (temp == '1') {
                int soTemp = 1;
                //System.out.println(i);
                for (int j = 0; j < i; j++) {
                    
                    soTemp *= 2;
                    //System.out.println(soTemp);
                }                
                soThapPhan += soTemp;
            }
            
        }
        System.out.println("Nhap vao so thap phan:" + soThapPhan);
    }
}
