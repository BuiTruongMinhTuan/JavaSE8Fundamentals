/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import static bai7_buitruongminhtuan.bai7_9.nhap;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_9_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int[] anArray = nhap();
        xuat(anArray);
        ktMang(anArray);
    }

    static int[] nhap() throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so n phan tu cu mang:");
        int readNum = Integer.parseInt(input.readLine());
        int[] anArray = new int[readNum];
        System.out.println("Nhap vao gia tri cua mang:");

        for (int i = 0; i < anArray.length; i++) {
            anArray[i] = Integer.parseInt(input.readLine());
        }
        return anArray;
    }

    static void xuat(int[] anArray) {
        System.out.println("mang ban da :");
        for (int i = 0; i < anArray.length; i++) {
            System.out.print(anArray[i] + " ");
        }
        System.out.println("\n");
    }

    static void ktMang(int[] anArray) {
        System.out.print("Cac so co quan he gap 2 lan nhau: ");
        for (int i = 0; i < anArray.length - 1; i++) {
            for (int j = i + 1; j < anArray.length; j++) {
                if (anArray[i] == anArray[j] * 2
                        || anArray[j] == anArray[i] * 2) {
                    System.out.print(anArray[i] + " & " + anArray[j] + " ");
                }
            }
        }

        System.out.println("\n");
        System.out.print("Cac so co quan he tong = 8: ");
        for (int i = 0; i < anArray.length - 1; i++) {
            for (int j = i + 1; j < anArray.length; j++) {
                if (anArray[i] + anArray[j] == 8) {
                    System.out.print(anArray[i] + " & " + anArray[j] + " ");
                }
            }
        }
    }
}
