/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        float chieuCao=nhapChieuCao();
        int canNang=nhapCanNang();
        danhGiaBMI(tinhBMI(chieuCao, canNang));
    }
    static float nhapChieuCao() throws IOException {
        float chieuCao = 0f;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap chieu cao:");
        chieuCao = Float.parseFloat(input.readLine());
        return chieuCao;
    }
    static int nhapCanNang() throws IOException {
        int canNang = 0;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap can nang:");
        canNang = Integer.parseInt(input.readLine());
        return canNang;
    }
    static float tinhBMI(float chieuCao,int canNang)
    {
        float BMI=canNang/(chieuCao*chieuCao);
        
        return BMI;
    }
    static void danhGiaBMI(float BMI)
    {
        if(BMI<18.5)
        {
            System.out.println("Ban hoi bi gay");
        }
        else if(BMI<25)
        {
            System.out.println("Ban binh thuong");
        }
        else
        {
            System.out.println("Ban thua can");
        }
    }
    
}
