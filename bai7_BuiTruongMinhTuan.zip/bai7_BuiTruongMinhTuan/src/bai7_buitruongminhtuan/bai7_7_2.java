/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int []anArray=nhap();
        xuat(anArray);
        timX(anArray);
    }
    static int[] nhap() throws IOException {
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so n phan tu cu mang:");
        int readNum = Integer.parseInt(input.readLine());
        int[] anArray = new int[readNum];
        System.out.println("Nhap vao gia tri cua mang:");

        for (int i = 0; i < anArray.length; i++) {
            anArray[i] = Integer.parseInt(input.readLine());
        }
        return anArray;
    }
    static void xuat(int[]anArray)
    {
         System.out.println("mang ban da :");
        for (int i = 0; i < anArray.length; i++) {
            System.out.print(anArray[i] + " ");
        }
    }
    static void timX(int[]anArray) throws IOException
    {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao gia tri can tim X:");
        int soX = Integer.parseInt(input.readLine());
        int soLonNhat = 0;

        for (int i = 0; i < anArray.length; i++) {

            if (anArray[i] == soX) {
                System.out.println("tim  thay" + soX + " tai vi tri " + i);
                break;

            } else {
                System.out.println("tim khong tim thay " + soX);
            }
            soLonNhat = Math.max(soLonNhat, anArray[i]);

        }
        if (soX == soLonNhat) {
            System.out.println(soX + "la so lon nhat trong mang ");
        } else {
            System.out.println("cac so lon hon  " + soX);
            for (int i = 0; i < anArray.length; i++) {
                if (anArray[i] > soX) {
                    System.out.print(anArray[i] + " ");
                }
            }
        }
    }
    
}
