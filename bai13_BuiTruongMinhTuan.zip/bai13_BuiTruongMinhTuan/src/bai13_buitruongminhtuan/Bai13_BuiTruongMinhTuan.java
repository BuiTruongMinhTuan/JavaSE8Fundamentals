/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13_buitruongminhtuan;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author hocvien
 */
public class Bai13_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String pattern= "dd/MM/yyyy";
        SimpleDateFormat dateFomat = new SimpleDateFormat(pattern);
        Date date = new Date();
        String now= dateFomat.format(date);
        System.out.println("ngay hom nay: "+now);
        Calendar calendar= Calendar.getInstance();
        System.out.println("ngay hom thu: "+calendar.get(Calendar.DAY_OF_WEEK));
        System.out.println("ngay hom tuan: "+calendar.get(Calendar.WEEK_OF_YEAR)+" trong nam");
        calendar.add(Calendar.WEEK_OF_YEAR, 1);
        System.out.println("ngay cua tuan sau: "+dateFomat.format(calendar.getTime()));
    }
    
}
