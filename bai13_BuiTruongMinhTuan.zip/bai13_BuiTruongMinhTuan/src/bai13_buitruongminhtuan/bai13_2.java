/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai13_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap ngay sinh nhat cua ban theo dinh dang (dd/mm/yyyy)");
        String ngaySinh=input.readLine();
        String dinhdang="(0?[1-9]|12?[0-9]|301?)/(0?[1-9]|1[012])/(\\d{4})";
        Pattern mau = Pattern.compile(dinhdang);
        Matcher dung = mau.matcher(ngaySinh);
        boolean kt = dung.matches();
        if (kt) {
            System.out.println("ban nhap dung dinh dang ");
            String[]days=ngaySinh.split("/");
            LocalDate homNay =LocalDate.now();
            LocalDate sinhNhat=LocalDate.of(homNay.getYear(),Integer.parseInt(days[1]), Integer.parseInt(days[0]));
            Period p = Period.between(sinhNhat, homNay);
            if(p.getMonths()==0&&p.getDays()==0)
            {
                System.out.println("Chuc mung sinh nhat");
            }
            else if(p.getMonths()>0||p.getMonths()==0&&p.getDays()==0){
                System.out.println("Sinh nhat ban da qua doi nam sau!!");
            }
            else if(p.getDays()<0)
            {
                System.out.println("Sinh nhat ban sap den!!");
            }
        } else {
            System.out.println("ban sai dinh dang ");
        }
    }
    
}
