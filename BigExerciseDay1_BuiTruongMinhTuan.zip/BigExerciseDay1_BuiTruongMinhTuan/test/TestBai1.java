/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday1_buitruongminhtuan.BigExerciseDay1_BuiTruongMinhTuan;

/**
 *
 * @author hocvien
 */
public class TestBai1 {
    
    public TestBai1() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        double ex=70000;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX", 1024);
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void test2() {
        double ex=100000;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX100", 1024);
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void test3() {
        double ex=200000;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX200", 1024);
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void test4() {
        double ex=50000;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAXS", 1024);
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void test5() {
        double ex=1536;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("M0", 1024);
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void test6() {
        double ex=1536;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX", 1024);
        assertNotEquals(ex, ac);
    }
    @Test
    public void test7() {
        double ex=1536;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX100", 1024);
        assertNotEquals(ex, ac);
    }
    @Test
    public void test8() {
        double ex=1536;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAX200", 1024);
        assertNotEquals(ex, ac);
    }
    @Test
    public void test9() {
        double ex=1536;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("MAXS", 1024);
        assertNotEquals(ex, ac);
    }
    @Test
    public void test10() {
        double ex=2000;
        double ac=BigExerciseDay1_BuiTruongMinhTuan.tinhCuoc("M0", 1024);
        assertNotEquals(ex, ac);
    }
}
