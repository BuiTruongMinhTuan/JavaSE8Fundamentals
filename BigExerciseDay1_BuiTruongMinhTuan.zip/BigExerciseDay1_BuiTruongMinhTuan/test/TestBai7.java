/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday1_buitruongminhtuan.Bai7;

/**
 *
 * @author hocvien
 */
public class TestBai7 {
    
    public TestBai7() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int ac=Bai7.doiSangThapPhan("AD");
        int ex=173;
        assertEquals(ex, ac);
    }
    @Test
    public void test2() {
        int ac=Bai7.doiSangThapPhan("AF");
        int ex=175;
        assertEquals(ex, ac);
    }
    @Test
    public void test3() {
        int ac=Bai7.doiSangThapPhan("FD");
        int ex=253;
        assertEquals(ex, ac);
    }
    @Test
    public void test4() {
        int ac=Bai7.doiSangThapPhan("CD");
        int ex=205;
        assertEquals(ex, ac);
    }
    @Test
    public void test5() {
        int ac=Bai7.doiSangThapPhan("BF");
        int ex=191;
        assertEquals(ex, ac);
    }
    @Test
    public void test6() {
        int ac=Bai7.doiSangThapPhan("BF");
        int ex=190;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test7() {
        int ac=Bai7.doiSangThapPhan("AF");
        int ex=123;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test8() {
        int ac=Bai7.doiSangThapPhan("CF");
        int ex=145;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test9() {
        int ac=Bai7.doiSangThapPhan("BF");
        int ex=32;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test10() {
        int ac=Bai7.doiSangThapPhan("FF");
        int ex=43;
        assertNotEquals(ex, ac);
    }
}
