/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday1_buitruongminhtuan.Bai2;

/**
 *
 * @author hocvien
 */
public class TestBai2 {

    public TestBai2() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int[][] maTranVuong = {{1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 6;
        assertEquals(ex, ac);
    }
    @Test
    public void test2() {
        int[][] maTranVuong = {{1, -2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 5;
        assertEquals(ex, ac);
    }
    @Test
    public void test3() {
        int[][] maTranVuong = {{1, 4, -5}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 5;
        assertEquals(ex, ac);
    }
    @Test
    public void test4() {
        int[][] maTranVuong = {{1, -2, -3}, {-2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 4;
        assertEquals(ex, ac);
    }
    @Test
    public void test5() {
        int[][] maTranVuong = {{-1, 2, -3}, {2, -3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 3;
        assertEquals(ex, ac);
    }
    @Test
    public void test6() {
        int[][] maTranVuong = {{1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 4;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test7() {
        int[][] maTranVuong = {{1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 3;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test8() {
        int[][] maTranVuong = {{1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 2;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test9() {
        int[][] maTranVuong = {{1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 1;
        assertNotEquals(ex, ac);
    }
    @Test
    public void test10() {
        int[][] maTranVuong = {{-1, 2, 3}, {2, 3, 4}, {3, 4, 5}};
        int ac = Bai2.demCacGTDuong(maTranVuong);
        int ex = 6;
        assertNotEquals(ex, ac);
    }
}
