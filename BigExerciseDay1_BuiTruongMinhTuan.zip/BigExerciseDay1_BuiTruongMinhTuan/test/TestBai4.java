/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday1_buitruongminhtuan.Bai4;

/**
 *
 * @author hocvien
 */
public class TestBai4 {
    
    public TestBai4() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
     public void test1() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=5;
         assertEquals(ex, ac);
     }
     @Test
     public void test2() {
         String[] mangChuoi={"abc","abcd","abcdef"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=6;
         assertEquals(ex, ac);
     }
     @Test
     public void test3() {
         String[] mangChuoi={"abc","abcd","abcdefg"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=7;
         assertEquals(ex, ac);
     }
     @Test
     public void test4() {
         String[] mangChuoi={"abc","abcd","abcdefgh"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=8;
         assertEquals(ex, ac);
     }
     @Test
     public void test5() {
         String[] mangChuoi={"abc","abcd","abcdefghs"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=9;
         assertEquals(ex, ac);
     }
     @Test
     public void test6() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=2;
         assertNotEquals(ex, ac);
     }
     @Test
     public void test7() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=3;
         assertNotEquals(ex, ac);
     }
     @Test
     public void test8() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=4;
         assertNotEquals(ex, ac);
     }
     @Test
     public void test9() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=7;
         assertNotEquals(ex, ac);
     }
     @Test
     public void test10() {
         String[] mangChuoi={"abc","abcd","abcde"};
         int ac=Bai4.ktDaiNhat(mangChuoi);
         int ex=8;
         assertNotEquals(ex, ac);
     }
}
