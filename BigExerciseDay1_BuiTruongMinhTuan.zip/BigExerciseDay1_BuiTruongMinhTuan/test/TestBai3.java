/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday1_buitruongminhtuan.Bai3;

/**
 *
 * @author hocvien
 */
public class TestBai3 {

    public TestBai3() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        double ac = Bai3.tinhCuoc("GP", 4);
        double ex = 316000;
        assertEquals(ex, ac, 0.1);
    }

    @Test
    public void test2() {
        double ac = Bai3.tinhCuoc("GP", 5);
        double ex = 395000;
        assertEquals(ex, ac, 0.1);
    }

    @Test
    public void test3() {
        double ac = Bai3.tinhCuoc("GP", 6);
        double ex = 474000;
        assertEquals(ex, ac, 0.1);
    }

    @Test
    public void test4() {
        double ac = Bai3.tinhCuoc("GP", 7);
        double ex = 553000;
        assertEquals(ex, ac, 0.1);
    }

    @Test
    public void test5() {
        double ac = Bai3.tinhCuoc("GP", 8);
        double ex = 632000;
        assertEquals(ex, ac, 0.1);

    }
     @Test
    public void test6() {
        double ac = Bai3.tinhCuoc("GP", 4);
        double ex = 632000;
        assertNotEquals(ex, ac, 0.1);

    }
     @Test
    public void test7() {
        double ac = Bai3.tinhCuoc("GP", 3);
        double ex = 233000;
        assertNotEquals(ex, ac, 0.1);

    }
     @Test
    public void test8() {
        double ac = Bai3.tinhCuoc("GP", 4);
        double ex = 22000;
        assertNotEquals(ex, ac, 0.1);

    }
     @Test
    public void test9() {
        double ac = Bai3.tinhCuoc("GP", 8);
        double ex = 32000;
        assertNotEquals(ex, ac, 0.1);

    }
     @Test
    public void test10() {
        double ac = Bai3.tinhCuoc("GP", 5);
        double ex = 232000;
        assertNotEquals(ex, ac, 0.1);

    }
}
