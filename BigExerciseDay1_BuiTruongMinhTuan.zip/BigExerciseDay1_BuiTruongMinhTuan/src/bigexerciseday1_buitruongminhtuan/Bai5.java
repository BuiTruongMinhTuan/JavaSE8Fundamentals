/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap n phan tu ");
        int n = 0;
        try {
            n = Integer.parseInt(input.readLine());
        } catch (NumberFormatException num) {
            System.out.println("Vui Long nhap so: " + num.toString());
        }
        int[] mang = new int[n];
        Random random = new Random();
        for (int i = 0; i < mang.length; i++) {
            mang[i] = random.nextInt(n);
        }
        System.out.println("mang ngau nhien: ");
        for (int i = 0; i < mang.length; i++) {
            System.out.print(mang[i] + " ");
        }
        taoMaTran(mang);
    }

    static void taoMaTran(int[] mang) {
        String[][] maTran = new String[mang.length][mang.length];
        for (int i = 0; i < maTran.length; i++) {
            for (int j = 0; j < maTran[i].length; j++) {
                maTran[i][mang[i]] = "Q";
                if (maTran[i][j] == null) {
                    maTran[i][j] = "*";
                }
            }
        }
        System.out.println("ma tran duoc tao tu mang:");
        for (int i = 0; i < maTran.length; i++) {
            for (int j = 0; j < maTran[i].length; j++) {
                System.out.print(maTran[i][j]+" ");
            }System.out.println();
        }

    }

}
