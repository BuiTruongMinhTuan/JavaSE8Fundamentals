package bigexerciseday1_buitruongminhtuan;

import static bigexerciseday1_buitruongminhtuan.BigExerciseDay1_BuiTruongMinhTuan.ktGoiCuoc;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        boolean kt = true;
        while (kt) {
            String[] mangLoaiVe = {"A2T", "A2TL", "AnLT1", "AnLT2", "BnLT1", "BnLT2", "BnLT3", "GP", "NC", "NCL", "NM", "NML", "NML4V"};
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("nhap loai ghe:");
            String loaiVe = "";
            loaiVe = input.readLine();
            if (ktGoiCuoc(mangLoaiVe, loaiVe)) {
                kt = false;
            } else {
                kt = true;
                System.out.println("Ban nhap sai ten loai ve vui long nhap lai:");
                continue;
            }
            System.out.println("nhap tong so ve:");
            int tongSoVe = 0;
            try {
                tongSoVe = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            System.out.println("nhap so ve nguoi gia:");
            int veNguoiGia = 0;
            try {
                veNguoiGia = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            System.out.println("nhap so ve tre em:");
            int veTreEm = 0;
            try {
                veTreEm = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            int veNguoiLon = 0;
            if (veNguoiGia + veTreEm < tongSoVe) {
                veNguoiLon = tongSoVe - veNguoiGia - veTreEm;
            }
            if (veNguoiGia + veTreEm > tongSoVe) {
                tongSoVe = veNguoiGia + veTreEm;
            }
            tinhTien(loaiVe, tongSoVe, veNguoiGia, veTreEm, veNguoiLon);

        }
    }

    static void tinhTien(String loaiVe, int tongVe, int veNguoiGia, int veTreEm, int veNguoiLon) {
        System.out.println("tong ve: " + tongVe);
        System.out.print("ve nguoi lon: " + veNguoiLon + " Thanh tien: ");
        double tienNL = tinhCuoc(loaiVe, veNguoiLon);
        System.out.println(tienNL + " VND");
        System.out.print("ve tre em: " + veTreEm + " Thanh tien: ");
        double tienTE = tinhCuoc(loaiVe, veTreEm);
        tienTE -= (tienTE * 50 / 100);
        System.out.println(tienTE + " VND");
        System.out.print("ve nguoi gia: " + veNguoiGia + " Thanh tien: ");
        double tienNG = tinhCuoc(loaiVe, veNguoiGia);
        tienNG -= (tienNG * 25 / 100);
        System.out.println(tienNG + " VND");
        double tongTien = tienNG + tienNL + tienTE;
        System.out.println("Tong so tien " + tongTien + " VND");

    }

    public static double tinhCuoc(String loaiVe, int soNguoi) {
        double thanhTien = 0;
        switch (loaiVe) {
            case "A2T":
                int veA2T = 129000;
                thanhTien = soNguoi * veA2T;
                break;
            case "A2TL":
                int veA2TL = 128000;
                thanhTien = soNguoi * veA2TL;
                break;
            case "A2TL1":
                int veA2TL1 = 249000;
                thanhTien = soNguoi * veA2TL1;
                break;
            case "A2TL2":
                int veA2TL2 = 218000;
                thanhTien = soNguoi * veA2TL2;
                break;
            case "AnT1":
                int AnT1 = 202000;
                thanhTien = soNguoi * AnT1;
                break;
            case "AnT2":
                int AnT2 = 172000;
                thanhTien = soNguoi * AnT2;
                break;
            case "BnTL1":
                int BnTL1 = 214000;
                thanhTien = soNguoi * BnTL1;
                break;
            case "BnTL2":
                int BnTL2 = 189000;
                thanhTien = soNguoi * BnTL2;
                break;
            case "BnTL3":
                int BnTL3 = 163000;
                thanhTien = soNguoi * BnTL3;
                break;
            case "BnT1":
                int BnT1 = 193000;
                thanhTien = soNguoi * BnT1;
                break;
            case "BnT2":
                int BnT2 = 168000;
                thanhTien = soNguoi * BnT2;
                break;
            case "BnT3":
                int BnT3 = 146000;
                thanhTien = soNguoi * BnT3;
                break;
            case "GP":
                int GP = 79000;
                thanhTien = soNguoi * GP;
                break;
            case "NC":
                int NC = 99000;
                thanhTien = soNguoi * NC;
                break;
            case "NCL":
                int NCL = 116000;
                thanhTien = soNguoi * NCL;
                break;
            case "NM":
                int NM = 129000;
                thanhTien = soNguoi * NM;
                break;
            case "NML":
                int NML = 155000;
                thanhTien = soNguoi * NML;
                break;
            case "NML4V":
                int NML4V = 171000;
                thanhTien = soNguoi * NML4V;
                break;
            default:
        }
        return thanhTien;
    }

    static boolean ktLoaiVe(String[] mangLoaiVe, String loaiVe) {
        boolean kt = false;
        for (int i = 0; i < mangLoaiVe.length; i++) {
            if (loaiVe.equals(mangLoaiVe[i])) {
                kt = true;
                break;
            }
        }
        return kt;
    }
}
