/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        boolean kt = true;
        while (kt) {
            System.out.println("nhap vao n so dong va cot cua ma tran vuong");
            int n = 0;
            try {
                n = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            int[][] maTranVuong = new int[n][n];
            System.out.println("Nhap vao gia tri cua mang:");
            for (int i = 0; i < maTranVuong.length; i++) {
                for (int j = 0; j < maTranVuong[i].length; j++) {
                    System.out.println("vi tri:" + i + " " + j);
                    try {
                        maTranVuong[i][j] = Integer.parseInt(input.readLine());
                    } catch (NumberFormatException num) {
                        kt = true;
                        System.out.println("Vui Long nhap so: " + num.toString());
                        continue;
                    }
                    kt = false;

                }

            }
            System.out.println("mang ban da nhap:");
            for (int[] dong : maTranVuong) {
                for (int i : dong) {
                    System.out.print(i + " ");
                }
                System.out.print("\n");
            }
            timSLN(maTranVuong);
            System.out.println("nhap so nguyen x");
            int x = 0;
            try {
                x = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            thayGiaTriDuongCheoChinh(maTranVuong, x);
            timGiaTriAmLNN(maTranVuong);
            int dem = demCacGTDuong(maTranVuong);
            System.out.println("so duong tren tam giac tren duong cheo chinh: " + dem);
            demSoCHC2Va3(maTranVuong);
        }
    }

    static void demSoCHC2Va3(int[][] maTranVuong) {
        int dem = 0;
        for (int i = 0; i < maTranVuong.length; i++) {
            for (int j = 0; j < maTranVuong[i].length; j++) {

                if (maTranVuong[i][j] % 2 == 0 && maTranVuong[i][j] % 3 == 0) {
                    dem++;
                }

            }
        }
        System.out.println("Co " + dem + " so chia het co 2 va 3.");
    }

    public static int demCacGTDuong(int[][] maTranVuong) {
        int dem = 0;
        for (int i = 0; i < maTranVuong.length; i++) {
            for (int j = 0; j < maTranVuong[i].length; j++) {
                if (i <= j) {
                    if (maTranVuong[i][j] > 0) {
                        dem++;
                    }
                }
            }
        }
        return dem;
    }

    static void timGiaTriAmLNN(int[][] maTranVuong) {
        int soAmLN = 0;
        int soDuongNN = 0;
        for (int i = 0; i < maTranVuong.length; i++) {
            for (int j = 0; j < maTranVuong[i].length; j++) {
                if (maTranVuong[i][j] < 0) {
                    if (soAmLN == 0) {
                        soAmLN = maTranVuong[i][j];
                    } else {
                        soAmLN = Math.max(soAmLN, maTranVuong[i][j]);
                    }
                } else if (maTranVuong[i][j] > 0) {
                    if (soDuongNN == 0) {
                        soDuongNN = maTranVuong[i][j];
                    } else {
                        soDuongNN = Math.min(soDuongNN, maTranVuong[i][j]);
                    }
                }
            }
        }
        System.out.println("So am lon nhat " + soAmLN);
        System.out.println("So duong nho nhat " + soDuongNN);
    }

    static void thayGiaTriDuongCheoChinh(int[][] maTranVuong, int x) {
        for (int i = 0; i < maTranVuong.length; i++) {
            for (int j = 0; j < maTranVuong[i].length; j++) {
                if (i == j || i + j == maTranVuong.length - 1) {
                    maTranVuong[i][j] = x;
                }

            }
        }
        for (int[] dong : maTranVuong) {
            for (int i : dong) {
                System.out.print(i + " ");
            }
            System.out.print("\n");
        }
    }

    static void timSLN(int[][] maTranVuong) {
        int max = 0;
        int min = 0;
        for (int i = 0; i < maTranVuong.length; i++) {
            max = min = maTranVuong[i][0];
            for (int j = 0; j < maTranVuong[i].length; j++) {

                max = Math.max(max, maTranVuong[i][j]);
                min = Math.min(min, maTranVuong[i][j]);

            }
            System.out.println("dong " + i + " SLN " + max + " SNN " + min);
        }
    }

}
