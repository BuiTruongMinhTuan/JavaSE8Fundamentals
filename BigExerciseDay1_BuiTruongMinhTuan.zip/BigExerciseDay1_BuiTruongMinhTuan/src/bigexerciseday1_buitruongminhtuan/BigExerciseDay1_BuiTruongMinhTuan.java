/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class BigExerciseDay1_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        boolean kt = true;
        while (kt) {
                String[]mangCuoc={"M0","M10","M25","M50","M120","MAX","MAX100","MAX200","MAXS"};
                BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                System.out.println("nhap ten goi cuoc:");
                String tenGoiCuoc;
                tenGoiCuoc = input.readLine().toUpperCase();
                if(ktGoiCuoc(mangCuoc, tenGoiCuoc))
                {
                    kt=false;
                }
                else
                {
                    kt=true;
                    System.out.println("Ban nhap sai ten goi cuoc vui long nhap lai:");
                    continue;
                }
                System.out.println("dung luong su dung (KB)");
                double dungLuong=0;
                try{
                dungLuong = Double.parseDouble(input.readLine());
                }catch(NumberFormatException num)
                {
                    kt=true;
                    System.out.println("Vui Long nhap so: "+ num.toString());
                    continue;
                }
                double thanhTien = 0;
                 kt=false;
                thanhTien = tinhCuoc(tenGoiCuoc, dungLuong);
                System.out.println("thanh tien: " + thanhTien);
           
        } 

    }
    static boolean ktGoiCuoc(String[]mangCuoc,String tenGoiCuoc)
    {
        boolean kt=false;
        for(int i=0;i<mangCuoc.length;i++)
        {
            if(tenGoiCuoc.equals(mangCuoc[i]))
            {
                kt=true;
                break;
            }
        }
        return kt;
    }
    public static double tinhCuoc(String tenGoiCuoc, double dungLuong) {
        double thanhTien = 0;

        switch (tenGoiCuoc) {
            case "M0":
                thanhTien = dungLuong * 1.5;
                break;
            case "M10":
                int cuocM10 = 10000;
                int dungLuongM10 = 50 * 1024;
                if (dungLuong <= dungLuongM10) {
                    thanhTien = cuocM10;
                } else {
                    thanhTien = cuocM10;
                    thanhTien += (dungLuong - dungLuongM10) * 0.5;
                }
                break;
            case "M25":
                int cuocM25 = 25000;
                int dungLuongM25 = 150 * 1024;
                if (dungLuong <= dungLuongM25) {
                    thanhTien = cuocM25;
                } else {
                    thanhTien = cuocM25;
                    thanhTien += (dungLuong - dungLuongM25) * 0.5;
                }
                break;
            case "M50":
                int cuocM50 = 50000;
                int dungLuongM50 = 500 * 1024;
                if (dungLuong <= dungLuongM50) {
                    thanhTien = cuocM50;
                } else {
                    thanhTien = cuocM50;
                    thanhTien += (dungLuong - dungLuongM50) * 0.5;
                }
                break;
            case "M120":
                int cuocM120 = 120000;
                double dungLuongM120 = 1.5 * 1024 * 1024;
                if (dungLuong <= dungLuongM120) {
                    thanhTien = cuocM120;
                } else {
                    thanhTien = cuocM120;
                    thanhTien += (dungLuong - dungLuongM120) * 0.5;
                }
                break;
            case "MAX":
                int cuocMax = 70000;
                thanhTien = cuocMax;
                break;
            case "MAX100":
                int cuocMax100 = 100000;
                thanhTien = cuocMax100;
                break;
            case "MAX200":
                int cuocMax200 = 200000;
                thanhTien = cuocMax200;
                break;
            case "MAXS":
                int cuocMaxS = 50000;
                thanhTien = cuocMaxS;
                break;
            default:
        }
        return thanhTien;
    }

}
