/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        boolean kt = true;
        while (kt) {
            System.out.println("nhap tuy chon 1 hoac 2 ");
            int n = 0;
            try {
                n = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                System.out.println("Vui Long nhap so: " + num.toString());
                kt = true;
                continue;
            }
            if (n != 1 && n != 2) {
                System.out.println("chi nhap 1 hoac 2 vui long nhap lai");
                kt = true;
                continue;
            }
            kt = false;
            if (n == 1) {
                System.out.println("nhap so thap phan");
                int soThapPhan = 0;
                try {
                    soThapPhan = Integer.parseInt(input.readLine());
                } catch (NumberFormatException num) {
                    System.out.println("Vui Long nhap so: " + num.toString());
                    kt = true;
                    continue;
                }
                StringBuilder chuoiThapLucPhan = new StringBuilder();
                chuoiThapLucPhan = doiSangThapLucPhan(soThapPhan, chuoiThapLucPhan);
                System.out.println("Chuoi thap luc phan: " + chuoiThapLucPhan);
            } else if (n == 2) {
                System.out.println("nhap so thap luc phan");
                String soThapLucPhan = input.readLine().toUpperCase();
                int soThapPhan = 0;
                soThapPhan = doiSangThapPhan(soThapLucPhan);
                System.out.println("So thap phan: " + soThapPhan);
            }
        }

    }

    public static int doiSangThapPhan(String soThapLucPhan) {
        int soThapPhan = 0;
        int dem = soThapLucPhan.length() - 1;
        for (int soMu = 0; dem >= 0; soMu++) {
            if (soThapLucPhan.charAt(dem) != '0') {
                if (soThapLucPhan.charAt(dem) == '1') {
                    soThapPhan += Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '2') {
                    soThapPhan += 2 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '3') {
                    soThapPhan += 3 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '4') {
                    soThapPhan += 4 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '5') {
                    soThapPhan += 5 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '6') {
                    soThapPhan += 6 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '7') {
                    soThapPhan += 7 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '8') {
                    soThapPhan += 8 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == '9') {
                    soThapPhan += 9 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'A') {
                    soThapPhan += 10 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'B') {
                    soThapPhan += 11 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'C') {
                    soThapPhan += 12 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'D') {
                    soThapPhan += 13 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'E') {
                    soThapPhan += 14 * Math.pow(16, soMu);
                } else if (soThapLucPhan.charAt(dem) == 'F') {
                    soThapPhan += 15 * Math.pow(16, soMu);
                }
            }
            dem--;
        }
        return soThapPhan;
    }

    static StringBuilder doiSangThapLucPhan(int soThapPhan, StringBuilder chuoiThapLucPhan) {
        if (soThapPhan != 0) {
            doiSangThapLucPhan(soThapPhan / 16, chuoiThapLucPhan);
            int soDu = soThapPhan % 16;
            if (soDu > 9) {
                if (soDu == 10) {
                    chuoiThapLucPhan.append("A");
                } else if (soDu == 11) {
                    chuoiThapLucPhan.append("B");
                } else if (soDu == 12) {
                    chuoiThapLucPhan.append("C");
                } else if (soDu == 13) {
                    chuoiThapLucPhan.append("D");
                } else if (soDu == 14) {
                    chuoiThapLucPhan.append("E");
                } else if (soDu == 15) {
                    chuoiThapLucPhan.append("F");
                }
            } else {
                chuoiThapLucPhan.append(soDu);
            }
        }
        return chuoiThapLucPhan;
    }
}
