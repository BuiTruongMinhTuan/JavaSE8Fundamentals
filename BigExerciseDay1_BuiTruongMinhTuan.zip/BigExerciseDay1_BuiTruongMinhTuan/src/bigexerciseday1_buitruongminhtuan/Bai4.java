/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Array;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap n phan tu ");
        int n = 0;
        try {
            n = Integer.parseInt(input.readLine());
        } catch (NumberFormatException num) {
            System.out.println("Vui Long nhap so: " + num.toString());
        }
        String[] mangChuoi = new String[n];
        for (int i = 0; i < n; i++) {
            System.out.println("nhap chuoi thu " + (i + 1));
            mangChuoi[i] = input.readLine();

        }
        for (int i = 0; i < n; i++) {
            System.out.println("phan tu thu " + (i + 1) + ": " + mangChuoi[i]);
            System.out.println("co do dai la: " + mangChuoi[i].length());
        }
        int max = ktDaiNhat(mangChuoi);
        System.out.println("chuoi dai nhat: ");
        for (int i = 0; i < n; i++) {
            if (mangChuoi[i].length() == max) {
                System.out.println(mangChuoi[i]);
                System.out.println("vi tri " + i);
            }
        }
        System.out.println("nhap 1 chuoi bat ki");
        String chuoi = input.readLine();
        int viTriGiong = ktChuoi(mangChuoi, chuoi);
        if (viTriGiong > -1) {
            System.out.println("chuoi vua nhap giong voi phan tu " + viTriGiong + " Trong mang");
        } else {
            System.out.println("khong tim thay vi tri giong");
        }
        System.out.println("mang sao chep sau khi sap xep:");
        String[] mangSaoChep = new String[n];
        System.arraycopy(mangChuoi, 0, mangSaoChep, 0, mangChuoi.length);
        Arrays.sort(mangSaoChep);
        for (String string : mangSaoChep) {
            System.out.println(string);
        }
    }

    static int ktChuoi(String[] mangChuoi, String chuoi) {
        int viTri = -1;
        for (int i = 0; i < mangChuoi.length; i++) {
            if (mangChuoi[i].equals(chuoi)) {
                viTri = i;
                break;
            }
        }
        return viTri;
    }

    public static int ktDaiNhat(String[] mangChuoi) {

        int max = 0;
        for (int i = 0; i < mangChuoi.length; i++) {
            if (i == 0) {
                max = mangChuoi[0].length();
            } else {
                max = Math.max(max, mangChuoi[i].length());
            }
        }
        return max;
    }
}
