/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random random = new Random();
        int so = random.nextInt(9);
        int[] mangSo = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        mangSo = tronMang(mangSo, so);
        int[][] SoDoKu = taoSoDoKu(mangSo);
        xuatSoDoKu(SoDoKu);
    }

    public static int[] tronMang(int[] mangso, int n) {
        int[] mangtam = mangso.clone();
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < 8; i++) {
                int tam = mangtam[i];
                mangtam[i] = mangtam[i + 1];
                mangtam[i + 1] = tam;
            }
        }
        return mangtam;
    }

    public static int[][] taoSoDoKu(int[] mang) {
        int[][] temp = new int[9][9];
        for (int i = 0; i < 9; i++) {
            int[] temp1;
            if (i < 3) {
                temp1 = tronMang(mang, 3 * (i % 3));
            } else if (i < 6) {
                temp1 = tronMang(mang, 3 * (i % 3) + 1);
            } else {
                temp1 = tronMang(mang, 3 * (i % 3) + 2);
            }
            for (int j = 0; j < 9; j++) {
                temp[i][j] = temp1[j];
            }

        }
        return temp;
    }

    public static void xuatSoDoKu(int[][] soDoKu) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(soDoKu[i][j] + " ");
                if (j + 1 == 3 || (j + 1) == 6) {
                    System.out.print(" | ");
                }
            }
            if (i + 1 == 3 || (i + 1) == 6) {
                System.out.println();
                for (int k = 0; k < 25; k++) {
                    System.out.print("-");
                }
            }
            System.out.println();
        }
    }
}
