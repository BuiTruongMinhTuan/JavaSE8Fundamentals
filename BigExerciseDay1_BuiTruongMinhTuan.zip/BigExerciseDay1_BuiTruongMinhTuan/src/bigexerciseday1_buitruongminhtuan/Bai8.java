/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        boolean kt = true;
        while (kt) {
            System.out.println("nhap n phan tu ");
            int n = 0;
            try {
                n = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                System.out.println("Vui Long nhap so: " + num.toString());
                kt = true;
                continue;
            }
            kt = false;
            int[] mangDiem = new int[n];
            System.out.println("diem cua sinh vien:");
            taoMangNgauNhien(mangDiem);
        }
    }

    static void taoMangNgauNhien(int[] mang) {
        Random random = new Random();
        for (int i = 0; i < mang.length; i++) {
            mang[i] = random.nextInt(101);
        }

        int diem_0_9 = tinhDiem(mang, 0, 9);
        inDiem(0, 9, diem_0_9);
        int diem_10_19 = tinhDiem(mang, 10, 19);
        inDiem(10, 19, diem_10_19);
        int diem_20_29 = tinhDiem(mang, 20, 29);
        inDiem(20, 29, diem_20_29);
        int diem_30_39 = tinhDiem(mang, 30, 39);
        inDiem(30, 39, diem_30_39);
        int diem_40_49 = tinhDiem(mang, 40, 49);
        inDiem(40, 49, diem_40_49);
        int diem_50_59 = tinhDiem(mang, 50, 59);
        inDiem(50, 59, diem_50_59);
        int diem_60_69 = tinhDiem(mang, 60, 69);
        inDiem(60, 69, diem_60_69);
        int diem_70_79 = tinhDiem(mang, 70, 79);
        inDiem(70, 79, diem_70_79);
        int diem_80_89 = tinhDiem(mang, 80, 89);
        inDiem(80, 89, diem_80_89);
        int diem_90_100 = tinhDiem(mang, 90, 100);
        inDiem(90, 100, diem_90_100);
    }

    static int tinhDiem(int[] mang, int dau, int cuoi) {
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            if (mang[i] >= dau && mang[i] <= cuoi) {
                dem++;
            }
        }
        return dem;
    }

    static void inDiem(int dau, int cuoi, int dem) {

        System.out.print(dau + " - " + cuoi + ": ");
        for (int i = 1; i <= dem; i++) {
            System.out.print("*");
        }
        System.out.println();
    }
}
