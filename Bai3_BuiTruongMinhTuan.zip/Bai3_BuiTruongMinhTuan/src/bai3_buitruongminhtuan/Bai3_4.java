/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class Bai3_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int reslut=+1;
        System.out.println(reslut);
        
        reslut--;
        System.out.println(reslut);
        reslut++;
        System.out.println(reslut);
        
        reslut= -reslut;
        System.out.println(reslut);
        boolean success =false;
        System.out.println(success);
        System.out.println(!success);
    }
    
}
