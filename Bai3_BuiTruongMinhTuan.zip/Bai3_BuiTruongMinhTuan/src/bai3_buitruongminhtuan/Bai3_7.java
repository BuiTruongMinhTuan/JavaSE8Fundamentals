/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class Bai3_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x=5;
        int y=10;
        System.out.println("x is "+ Integer.toBinaryString(x));
        System.out.println("y is "+ Integer.toBinaryString(y));
        
        x >>=2;
        y >>=2;
        System.out.println("x>>2 is "+ Integer.toBinaryString(x));
        System.out.println("x>>2 is "+ Integer.toBinaryString(y));
        
        x <<=10;
        y <<=10;
        System.out.println("x<<10 is "+ Integer.toBinaryString(x));
        System.out.println("x<<10 is "+ Integer.toBinaryString(y));
        
        x >>>=10;
        y >>>=10;
        System.out.println("x>>>10 is "+ Integer.toBinaryString(x));
        System.out.println("x>>>10 is "+ Integer.toBinaryString(y));
        
    }
    
}
