/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap vao x:");
        float x=Integer.parseInt(input.readLine());
        float s= 1+x+(x*x*x/3)+(x*x*x*x*x/5);
        System.out.println("Gia tri bieu thuc:"+ String.format("%.1f", s));
        
    }
    
}
