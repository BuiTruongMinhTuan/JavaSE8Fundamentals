/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int[][] mang = taoMang();
        sapXepMang(mang);
        tinhTong(mang);
        thaySNTT(mang);
        tinhTongCotDong(mang);
        thaySoCP(mang);
    }

    static void thaySoCP(int[][] mang) {
        System.out.println("So Chinh Phuong la:");
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (ktSoChinhPhuong(mang[i][j]) == true) {
                    System.out.println(mang[i][j]+" Dong " + i + " Cot " + j);
                }
            }
        }
    }

    public static boolean ktSoChinhPhuong(int n) {
        if (n == (int) Math.sqrt(n) * (int) Math.sqrt(n)) {
            return true;
        }
        return false;
    }

    static void xuatMang(int[][] mang) {
        for (int[] is : mang) {
            for (int i : is) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }

    static void thaySNTT(int[][] mang) {
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (ktSNT(mang[i][j])) {
                    mang[i][j] = -1;
                }
            }

        }
        System.out.println("mang sau khi kt thay SNT = -1");
        xuatMang(mang);
    }

    static boolean ktSNT(int so) {

        if (so < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(so); i++) {
            if (so % i == 0) {
                return false;
            }

        }
        return true;
    }

    static void tinhTongCotDong(int[][] mang) {
        int[] max = new int[4];
        for (int i = 0; i < mang.length; i++) {
            max[0] += mang[i][0];
            max[1] += mang[i][mang[0].length - 1];
        }
        for (int i = 0; i < mang[0].length; i++) {
            max[2] += mang[0][i];
            max[3] += mang[mang.length - 1][i];
        }
        System.out.println("Tong phan dong dau tien: " + max[2]);
        System.out.println("Tong phan dong cuoi cung: " + max[3]);
        System.out.println("Tong phan cot dau tien: " + max[0]);
        System.out.println("Tong phan dong cuoi cung: " + max[1]);

    }

    static int[][] taoMang() {

        Random random = new Random();
        int[][] mang = {{random.nextInt(10), random.nextInt(10), random.nextInt(10)},
        {random.nextInt(10), random.nextInt(10), random.nextInt(10)},
        {random.nextInt(10), random.nextInt(10), random.nextInt(10)}};
        xuatMang(mang);
        return mang;
    }

    static void sapXepMang(int[][] mang) throws IOException {
        boolean kt = true;
        while (kt) {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("nhap nao so cot nho hon :" + mang.length);
            int soCot = 0;
            try {
                soCot = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            if (soCot > mang.length) {
                kt = true;
                System.out.println("so lon hon pham vi mang");
                continue;
            }
            int[] mangTemp = new int[mang.length];
            for (int i = 0; i < mang.length; i++) {
                mangTemp[i] = mang[i][soCot];
            }
            Arrays.sort(mangTemp);
            for (int i = 0; i < mang.length; i++) {
                mang[i][soCot] = mangTemp[i];
            }
            kt = false;
            xuatMang(mang);
        }
    }

    static void tinhTong(int[][] mang) {
        int max = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i % 2 == 0) {
                for (int j = 0; j < mang[i].length; j++) {
                    if (j % 2 != 0) {
                        max += mang[i][j];
                    }
                }
            }

        }
        System.out.println("Tong cac phan tu dong chan cot le la: " + max);
    }
}
