/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class BigExerciseDay2_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        taoDanhSach();

    }

    static void taoDanhSach() throws IOException {
        boolean kt = true;
        while (kt) {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("nhap trong luong buu pham (gram)");
            int trongLuong = 0;
            try {
                trongLuong = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }

            System.out.println("nhap hinh thuc gui (1-3)");
            int hinhThuc = 0;
            try {
                hinhThuc = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }

            System.out.println("chon 1 gui noi tinh, 2 gui lien tinh");
            int lienTinh = 0;
            try {
                lienTinh = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            kt = false;
            int vung = 0;
            int trongVung2 = 0;
            if (lienTinh == 2) {
                System.out.println("chon vung ");

                try {
                    vung = Integer.parseInt(input.readLine());
                } catch (NumberFormatException num) {
                    kt = true;
                    System.out.println("Vui Long nhap so: " + num.toString());
                    continue;
                }
                kt = false;

                if (vung == 2) {
                    System.out.println("chon 1 gui DaNang, chon 2 gui HaNoi");

                    try {
                        trongVung2 = Integer.parseInt(input.readLine());
                    } catch (NumberFormatException num) {
                        kt = true;
                        System.out.println("Vui Long nhap so: " + num.toString());
                        continue;
                    }
                    kt = false;
                }
            }

            double thanhTien = tinhCuoc(trongLuong, hinhThuc, lienTinh, vung, trongVung2);
            System.out.println("thanh tien: " + thanhTien);
            kt = false;

        }
    }

    public static double tinhCuoc(int trongLuong, int hinhThuc, int lienTinh, int vung, int trongVung2) {
        double thanhTien = 0;
        if (hinhThuc == 1) {
            thanhTien = tinhHinhThuc1(trongLuong, lienTinh, vung, trongVung2);
        } else if (hinhThuc == 2) {
            thanhTien = tinhHinhThuc2(trongLuong, lienTinh, vung, trongVung2);
        } else if (hinhThuc == 3) {
            thanhTien = tinhHinhThuc3(trongLuong, lienTinh, vung, trongVung2);
        }
        return thanhTien;
    }

    static double tinhHinhThuc3(int trongLuong, int lienTinh, int vung, int trongVung2) {
        double thanhTien = 0;
        int trongLuong1 = 2000;
        int TLtren = 500;
        if (lienTinh == 1) {
            if (trongLuong <= trongLuong1) {
                thanhTien = 50000;
            } else {
                int du = trongLuong - trongLuong1;
                int du1 = du / TLtren;
                int du2 = du % TLtren;
                if (du2 > 0) {
                    du1++;
                }
                thanhTien = 50000;
                thanhTien += du1 * 5000;
            }
        } else if (lienTinh == 2) {
            if (vung == 1) {
                if (trongLuong <= trongLuong1) {
                    thanhTien = 70000;
                } else {
                    int du = trongLuong - trongLuong1;
                    int du1 = du / TLtren;
                    int du2 = du % TLtren;
                    if (du2 > 0) {
                        du1++;
                    }
                    thanhTien = 70000;
                    thanhTien += du1 * 7000;
                }
            } else if (vung == 2) {
                if (trongVung2 == 1) {
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 85000;
                    } else {
                        int du = trongLuong - trongLuong1;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 85000;
                        thanhTien += du1 * 10000;
                    }
                } else if (trongVung2 == 2) {
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 100000;
                    } else {
                        int du = trongLuong - trongLuong1;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 100000;
                        thanhTien += du1 * 12000;
                    }
                }
            } else if (vung == 3) {
                if (trongLuong <= trongLuong1) {
                    thanhTien = 110000;
                } else {
                    int du = trongLuong - trongLuong1;
                    int du1 = du / TLtren;
                    int du2 = du % TLtren;
                    if (du2 > 0) {
                        du1++;
                    }
                    thanhTien = 110000;
                    thanhTien += du1 * 15000;
                }
            }
        }
        return thanhTien;
    }

    static double tinhHinhThuc2(int trongLuong, int lienTinh, int vung, int trongVung2) {
        double thanhTien = 0;
        int trongLuong1 = 2000;
        int TLtren = 500;
        if (lienTinh == 1) {
            if (trongLuong <= trongLuong1) {
                thanhTien = 50000;
            } else {
                int du = trongLuong - trongLuong1;
                int du1 = du / TLtren;
                int du2 = du % TLtren;
                if (du2 > 0) {
                    du1++;
                }
                thanhTien = 50000;
                thanhTien += du1 * 5000;
            }
        } else if (lienTinh == 2) {
            if (vung == 1) {
                if (trongLuong <= trongLuong1) {
                    thanhTien = 70000;
                } else {
                    int du = trongLuong - trongLuong1;
                    int du1 = du / TLtren;
                    int du2 = du % TLtren;
                    if (du2 > 0) {
                        du1++;
                    }
                    thanhTien = 70000;
                    thanhTien += du1 * 7000;
                }
            } else if (vung == 2) {
                if (trongVung2 == 1) {
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 110000;
                    } else {
                        int du = trongLuong - trongLuong1;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 110000;
                        thanhTien += du1 * 12000;
                    }
                } else if (trongVung2 == 2) {
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 113000;
                    } else {
                        int du = trongLuong - trongLuong1;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 113000;
                        thanhTien += du1 * 20000;
                    }
                }
            }
        }
        return thanhTien;
    }

    static double tinhHinhThuc1(int trongLuong, int lienTinh, int vung, int trongVung2) {
        double thanhTien = 0;
        int trongLuong1 = 50;
        int trongLuong2 = 100;
        int trongLuong3 = 250;
        int trongLuong4 = 500;
        int trongLuong5 = 1000;
        int trongLuong6 = 1500;
        int trongLuong7 = 2000;
        int TLtren = 500;
        if (lienTinh == 1) {
            if (trongLuong <= trongLuong2) {
                thanhTien = 8000;
            } else if (trongLuong <= trongLuong3) {
                thanhTien = 10000;
            } else if (trongLuong <= trongLuong4) {
                thanhTien = 12500;
            } else if (trongLuong <= trongLuong5) {
                thanhTien = 15000;
            } else if (trongLuong <= trongLuong6) {
                thanhTien = 18000;
            } else if (trongLuong <= trongLuong7) {
                thanhTien = 21000;
            } else {
                int du = trongLuong - trongLuong7;
                int du1 = du / TLtren;
                int du2 = du % TLtren;
                if (du2 > 0) {
                    du1++;
                }
                thanhTien = 21000;
                thanhTien += du1 * 1600;
            }
        } else if (lienTinh == 2) {
            switch (vung) {
                case 1:
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 8500;
                    } else if (trongLuong <= trongLuong2) {
                        thanhTien = 12500;
                    } else if (trongLuong <= trongLuong3) {
                        thanhTien = 16500;
                    } else if (trongLuong <= trongLuong4) {
                        thanhTien = 23500;
                    } else if (trongLuong <= trongLuong5) {
                        thanhTien = 33000;
                    } else if (trongLuong <= trongLuong6) {
                        thanhTien = 40000;
                    } else if (trongLuong <= trongLuong7) {
                        thanhTien = 48500;
                    } else {
                        int du = trongLuong - trongLuong7;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 48500;
                        thanhTien += du1 * 3800;

                    }
                    break;
                case 2:
                    System.out.println("2");
                    if (trongVung2 == 1) {
                        if (trongLuong <= trongLuong1) {
                            thanhTien = 9500;
                        } else if (trongLuong <= trongLuong2) {
                            thanhTien = 13500;
                        } else if (trongLuong <= trongLuong3) {
                            thanhTien = 20000;
                        } else if (trongLuong <= trongLuong4) {
                            thanhTien = 26500;
                        } else if (trongLuong <= trongLuong5) {
                            thanhTien = 38500;
                        } else if (trongLuong <= trongLuong6) {
                            thanhTien = 49500;
                        } else if (trongLuong <= trongLuong7) {
                            thanhTien = 59500;
                        } else {
                            int du = trongLuong - trongLuong7;
                            int du1 = du / TLtren;
                            int du2 = du % TLtren;
                            if (du2 > 0) {
                                du1++;
                            }
                            thanhTien = 59500;
                            thanhTien += du1 * 8500;
                            System.out.println(thanhTien);
                        }
                    } else if (trongLuong <= trongLuong1) {
                        thanhTien = 9500;
                    } else if (trongLuong <= trongLuong2) {
                        thanhTien = 13500;
                    } else if (trongLuong <= trongLuong3) {
                        thanhTien = 21500;
                    } else if (trongLuong <= trongLuong4) {
                        thanhTien = 28000;
                    } else if (trongLuong <= trongLuong5) {
                        thanhTien = 40500;
                    } else if (trongLuong <= trongLuong6) {
                        thanhTien = 52500;
                    } else if (trongLuong <= trongLuong7) {
                        thanhTien = 63500;
                    } else {
                        int du = trongLuong - trongLuong7;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 63500;
                        thanhTien += du1 * 8500;
                    }
                    break;
                case 3:
                    System.out.println("3");
                    if (trongLuong <= trongLuong1) {
                        thanhTien = 10000;
                    } else if (trongLuong <= trongLuong2) {
                        thanhTien = 14000;
                    } else if (trongLuong <= trongLuong3) {
                        thanhTien = 22500;
                    } else if (trongLuong <= trongLuong4) {
                        thanhTien = 29500;
                    } else if (trongLuong <= trongLuong5) {
                        thanhTien = 43500;
                    } else if (trongLuong <= trongLuong6) {
                        thanhTien = 55500;
                    } else if (trongLuong <= trongLuong7) {
                        thanhTien = 67500;
                    } else {
                        int du = trongLuong - trongLuong7;
                        int du1 = du / TLtren;
                        int du2 = du % TLtren;
                        if (du2 > 0) {
                            du1++;
                        }
                        thanhTien = 67500;
                        thanhTien += du1 * 9500;
                    }
                    break;
                default:

            }

        }

        return thanhTien;
    }

}
