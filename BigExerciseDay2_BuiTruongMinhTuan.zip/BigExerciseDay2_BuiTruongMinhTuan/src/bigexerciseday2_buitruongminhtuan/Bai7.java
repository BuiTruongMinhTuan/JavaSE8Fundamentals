/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String[] mang = taoMang();
        troChoi(mang);
    }

    static String[] taoMang() {
        String[] mang = {"program", "developer", "testing", "coder", "algorithm", "bug", "console", "user", "system", "application"};
        return mang;
    }

    static void troChoi(String[] mang) throws IOException {
        boolean kt = true;

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Chao mung ban den zoi tro choi doan chu:");
        System.out.println("Co :" + mang.length + " chu cai ban muon doan chu thu may");
        int viTri = 0;
        while (kt) {
            try {
                viTri = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            if (viTri < 0 || viTri > mang.length) {
                System.out.println("Ban nhap sai rui nhap lai ");
                continue;
            }
            kt = false;
        }
        String chuoi = mang[viTri];
        System.out.println("tu co " + chuoi.length() + " chu cai");
        char[] tuAn = new char[chuoi.length()];
        for (int i = 0; i < tuAn.length; i++) {
            tuAn[i] = chuoi.charAt(i);
        }
        char[] hienThi = new char[chuoi.length()];
        for (int i = 0; i < tuAn.length; i++) {
            hienThi[i] = '*';
            System.out.print(hienThi[i]);
        }
        System.out.println();
        String tu = "";

        boolean thang = false;
        kt = true;
        int soLanChoi=1;
        while (!thang) {
            while (kt) {
                System.out.println("Lan Doan thu "+soLanChoi);
                System.out.println("moi ban doan 1 tu");
                tu = input.readLine();
                if (tu.length() > 1) {
                    System.out.println("chi nhap 1 tu thui ");
                    continue;
                }
                int dem = 0;
                for (int i = 0; i < tuAn.length; i++) {
                    if (tuAn[i] == tu.charAt(0)) {
                        hienThi[i] = tuAn[i];
                        dem++;
                    }
                }
                if (dem > 0) {
                    System.out.println("ban doan dung rui co " + dem + " tu " + tu.charAt(0));
                } else {
                    System.out.println("ban doan sai rui");
                }
                for (int i = 0; i < hienThi.length; i++) {
                    System.out.print(hienThi[i]);
                }
                System.out.println();
                int diem=0;
                for (int i = 0; i < hienThi.length; i++) {
                    if(hienThi[i]==tuAn[i]){
                        diem++;
                    }
                }
                if(diem==tuAn.length)
                {
                    kt = false;
                    thang=true;
                }
                System.out.println("ban co muong doan luon chu ko? nhap (y) neu muon nhap (n) neu ko ");
                String doan="";
                        
                soLanChoi++;
            }

        }
        if(thang){
            System.out.println("Chuc mung ban da thang sau "+soLanChoi+" lan doan");
        }
    }
}
