/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        tinhTienNuoc();
    }

    static void tinhTienNuoc() throws IOException {
        boolean kt = true;
        double thanhTien = 0;
        while (kt) {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("nhap so m3 da dung");
            double soM3 = 0;
            try {
                soM3 = Double.parseDouble(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            System.out.println("chon doi tuong sinh hoat (1) hay khong (2)");
            int sinhHoat = 0;
            try {
                sinhHoat = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            if (sinhHoat == 1) {
                System.out.println("so nguoi trong gia dinh: ");
                int soNguoi = 0;
                try {
                    soNguoi = Integer.parseInt(input.readLine());
                } catch (NumberFormatException num) {
                    kt = true;
                    System.out.println("Vui Long nhap so: " + num.toString());
                    continue;
                }

                thanhTien = tinhTienNuocSinhHoat(soM3, soNguoi);
                System.out.println(thanhTien);
            } else {
                System.out.println("Loai co quan (1-3): ");
                int loaiCoQuan = 0;
                try {
                    loaiCoQuan = Integer.parseInt(input.readLine());
                } catch (NumberFormatException num) {
                    kt = true;
                    System.out.println("Vui Long nhap so: " + num.toString());
                    continue;
                }
                thanhTien = tinhTienNuocKoSinhHoat(soM3, loaiCoQuan);
            }
            kt = false;
        }
        double thueGTGT = thanhTien * 0.05;
        double thueMT = thanhTien * 0.1;
        double tongTien = thanhTien + thueGTGT + thueMT;
        System.out.println("Tien nuoc khong thue: " + thanhTien);
        System.out.println("Tien thue GTGT: " + thueGTGT);
        System.out.println("Tien phi bao ve moi truong: " + thueMT);
        System.out.println("Tong tien: " + tongTien);

    }

    public static double tinhTienNuocKoSinhHoat(double soM3, int loaiCoQuan) {
        double thanhTien = 0;
        int dv1 = 9600;
        int dv2 = 10300;
        int dv3 = 16900;
        if (loaiCoQuan == 1) {
            thanhTien = soM3 * dv1;
        } else if (loaiCoQuan == 2) {
            thanhTien = soM3 * dv2;
        } else {
            thanhTien = soM3 * dv3;
        }
        return thanhTien;
    }

    static double tinhTienNuocSinhHoat(double soM3, int soNguoi) {
        double thanhTien = 0;
        int dv1 = 5300;
        int dv2 = 10200;
        int dv3 = 11400;
        double temp = soM3 / soNguoi;
        if (temp <= 4) {
            thanhTien = temp * dv1;
        } else if (temp <= 6) {
            thanhTien = 4 * dv1;
            thanhTien += (temp - 4) * dv2;
        } else {
            thanhTien = 4 * dv1;
            thanhTien += 2 * dv2;
            thanhTien += (temp - 6) * dv3;
        }
        thanhTien *= soNguoi;
        return thanhTien;
    }
}
