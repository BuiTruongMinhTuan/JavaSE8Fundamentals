package bigexerciseday2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        taoMang();
    }

    static void taoMang() throws IOException {
        boolean kt = true;
        while (kt) {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("nhap so luong SV");
            int soSV = 0;
            try {
                soSV = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Vui Long nhap so: " + num.toString());
                continue;
            }
            int[] mangSV = new int[soSV];
            int i = 0;
            do {
                System.out.println("nhap vao diem cho SV " + (i + 1) + " :");
                try {
                    mangSV[i] = Integer.parseInt(input.readLine());
                } catch (NumberFormatException num) {
                    kt = true;
                    System.out.println("Vui Long nhap so: " + num.toString());
                    continue;
                }
                if (mangSV[i] < 0 || mangSV[i] > 10) {
                    System.out.println("Ban nhap sai rui nhap lai ");
                    continue;
                }

                i++;
            } while (i < soSV);
            System.out.println("The average is: " + tinhDiemTB(mangSV, soSV));
            System.out.println("The maximum is: " + timMax(mangSV, soSV));
            System.out.println("The minimum is: " + timMin(mangSV, soSV));
            kt = false;
        }

    }

    public static double tinhDiemTB(int[] mang, int n) {
        double diemTB = 0;
        for (int i = 0; i < mang.length; i++) {
            diemTB += mang[i];
        }
        return diemTB / n;
    }

    static int timMax(int[] mang, int n) {
        int max = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i == 0) {
                max = mang[i];
            } else if (mang[i] > max) {
                max = mang[i];
            }
        }
        return max;
    }

    static int timMin(int[] mang, int n) {
        int min = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i == 0) {
                min = mang[i];
            } else if (mang[i] < min) {
                min = mang[i];
            }
        }
        return min;
    }
}
