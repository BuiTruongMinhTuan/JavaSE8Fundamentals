/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class Bai6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 11; j++) {
                if (i <= j && j <= (10 - i)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
        System.out.println("         (a)\n");

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 11; j++) {
                if (j >= (5 - i) && j <= (5 + i)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
        System.out.println("         (b)\n");

        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 11; j++) {
                if (j >= (5 - i) && j <= (5 + i) && i < 6) {
                    System.out.print("# ");
                } else if (j >= (i - 5) && j <= (15 - i) && i > 5) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
        System.out.println("         (c)\n");

        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (i >= j) {
                    System.out.print(j + " ");
                }
            }
            System.out.println();
        }
        System.out.println("     (d)\n");

        int dem = 0;
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (i > j) {
                    System.out.print("  ");
                } else {
                    System.out.print(j - dem + " ");
                }
            }
            System.out.println();
            dem++;
        }
        System.out.println("     (e)\n");

        for (int i = 1; i <= 8; i++) {
            dem = 1;
            for (int j = 1; j <= 8; j++) {
                if (i + j <= 8) {
                    System.out.print("  ");
                    dem++;
                } else {
                    System.out.print((i + j - dem) + " ");
                    dem += 2;
                }
            }
            System.out.println();
        }
        System.out.println("     (f)\n");

        dem = 7;
        int temp = 0;
        for (int i = 1; i <= 8; i++) {
            temp = dem;
            for (int j = 1; j <= 8; j++) {
                if (i <= j) {
                    System.out.print((j + temp) + " ");
                    temp -= 2;
                }

            }
            System.out.println();
            dem -= 2;
        }
        System.out.println("     (g)\n");
    }
}

