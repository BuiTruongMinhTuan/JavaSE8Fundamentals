/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday2_buitruongminhtuan.Bai2;

/**
 *
 * @author hocvien
 */
public class TestBai2 {
    
    public TestBai2() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
    public void Test1() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(3, 2);
        double ex=30900;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test2() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(2, 2);
        double ex=20600;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test3() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(3, 1);
        double ex=28800;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test4() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(1, 2);
        double ex=10300;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test5() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(3, 3);
        double ex=50700;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test6() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(2, 3);
        double ex=10200;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test7() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(1, 3);
        double ex=10200;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test8() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(3, 2);
        double ex=10200;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test9() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(3, 3);
        double ex=10200;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test10() {
        double ac=Bai2.tinhTienNuocKoSinhHoat(2, 3);
        double ex=10200;
        assertNotEquals(ex, ac,0.1);
    }
}
