/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday2_buitruongminhtuan.BigExerciseDay2_BuiTruongMinhTuan;

/**
 *
 * @author hocvien
 */
public class TestBai1 {
    
    public TestBai1() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test1() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(300, 1, 1, 1, 1);
        double ex=12500;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test2() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(500, 1, 2, 1, 1);
        double ex=23500;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test3() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 1, 2, 2, 1);
        double ex=49500;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test4() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 1, 2, 2, 2);
        double ex=52500;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test5() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=100000;
        assertEquals(ex, ac,0.1);
    }
     @Test
    public void Test6() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=10000;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test7() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=8000;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test8() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=40000;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test9() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=40000;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test10() {
        double ac=BigExerciseDay2_BuiTruongMinhTuan.tinhCuoc(1100, 3, 2, 2, 2);
        double ex=6000;
        assertNotEquals(ex, ac,0.1);
    }
    
}
