/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday2_buitruongminhtuan.Bai3;

/**
 *
 * @author hocvien
 */
public class TestBai3 {

    public TestBai3() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test1() {
        boolean ac = Bai3.ktSoChinhPhuong(4);

        assertTrue(ac);
    }

    @Test
    public void Test2() {
        boolean ac = Bai3.ktSoChinhPhuong(8);

        assertFalse(ac);
    }

    @Test
    public void Test3() {
        boolean ac = Bai3.ktSoChinhPhuong(2);

        assertFalse(ac);
    }

    @Test
    public void Test4() {
        boolean ac = Bai3.ktSoChinhPhuong(4);

        assertTrue(ac);
    }

    @Test
    public void Test5() {
        boolean ac = Bai3.ktSoChinhPhuong(8);

        assertFalse(ac);
    }

    @Test
    public void Test6() {
        boolean ac = Bai3.ktSoChinhPhuong(4);

        assertTrue(ac);
    }
    @Test
    public void Test7() {
        boolean ac = Bai3.ktSoChinhPhuong(20);

        assertFalse(ac);
    }
    @Test
    public void Test8() {
        boolean ac = Bai3.ktSoChinhPhuong(8);

        assertFalse(ac);
    }
    @Test
    public void Test9() {
        boolean ac = Bai3.ktSoChinhPhuong(5);

        assertFalse(ac);
    }
    @Test
    public void Test10() {
        boolean ac = Bai3.ktSoChinhPhuong(12);

        assertFalse(ac);
    }
}
