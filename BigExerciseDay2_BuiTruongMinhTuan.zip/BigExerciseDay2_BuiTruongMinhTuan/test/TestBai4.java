/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bigexerciseday2_buitruongminhtuan.Bai4;

/**
 *
 * @author hocvien
 */
public class TestBai4 {
    
    public TestBai4() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
    public void Test1() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 3);
        double ex=7;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test2() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 2);
        double ex=10.5;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test3() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 4);
        double ex=5.25;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test4() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 6);
        double ex=3.5;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test5() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 5);
        double ex=4.2;
        assertEquals(ex, ac,0.1);
    }
    @Test
    public void Test6() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 8);
        double ex=3;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test7() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 4);
        double ex=8;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test8() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 5);
        double ex=3;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test9() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 5);
        double ex=2;
        assertNotEquals(ex, ac,0.1);
    }
     @Test
    public void Test10() {
        int[]mang={3,5,7,6};
        double ac=Bai4.tinhDiemTB(mang, 5);
        double ex=33;
        assertNotEquals(ex, ac,0.1);
    }
    
}
