/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai15_buitruongminhtuan.bai15_4;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author long
 */
public class TestBac2 {

    bai15_buitruongminhtuan.bai15_4 bai15 = new bai15_4();

    public TestBac2() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    boolean testNghiem(double[] nghiemPT) {
        boolean test;
        if (nghiemPT[2] == 1 || nghiemPT[2] == 2) {

            test = false;
        } else {
            test = true;
        }

        return test;
    }

    void testKQ(double[] mang, double ex) {
        
        if (testNghiem(mang)) {
            if (mang[1] == 0) {
                System.out.println("1");
                assertEquals(ex, mang[0], 0.1);

            } else {
                System.out.println("2");
                if (ex == mang[0]) {
                    assertEquals(ex, mang[0], 0.1);

                } else {
                    assertEquals(ex, mang[1], 0.1);
                }

            }
        }
    }

    @Test
    public void test1() {
        System.out.println("bai test 1");
        double[] mang = bai15.giaiPhuongTrinhBac2(-1, 4, -4);
        double ex = 2.0;
        testKQ(mang, ex);
    }
    @Test
    public void test2() {
        System.out.println("bai test 2");
        double[] mang = bai15.giaiPhuongTrinhBac2(3, -4, 1);
        double ex = 3.0;
        testKQ(mang, ex);
    }
    @Test
    public void test3() {
        System.out.println("bai test 3");
        double[] mang = bai15.giaiPhuongTrinhBac2(1, 2, -7);
        double ex = -3.828;
        testKQ(mang, ex);
    }
    @Test
    public void test4() {
        System.out.println("bai test 4");
        double[] mang = bai15.giaiPhuongTrinhBac2(3, -7, 2);
        double ex = 1.0;
        testKQ(mang, ex);
    }
    @Test
    public void test5() {
        System.out.println("bai test 5");
        double[] mang = bai15.giaiPhuongTrinhBac2(5, 3, -1);
        double ex = -0.838;
        testKQ(mang, ex);
    }
    @Test
    public void test6() {
        System.out.println("bai test 6");
        double[] mang = bai15.giaiPhuongTrinhBac2(2, 13, 8);
        double ex = 1.0;
        testKQ(mang, ex);
    }
    @Test
    public void test7() {
        System.out.println("bai test 7");
        double[] mang = bai15.giaiPhuongTrinhBac2(4, -11, 8);
        double ex = 1.0;
        testKQ(mang, ex);
    }
    @Test
    public void test8() {
        System.out.println("bai test 8");
        double[] mang = bai15.giaiPhuongTrinhBac2(6, 1, 5);
        double ex = 1.0;
        testKQ(mang, ex);
    }
    @Test
    public void test9() {
        System.out.println("bai test 9");
        double[] mang = bai15.giaiPhuongTrinhBac2(1, -8, 16);
        double ex = 4.0;
        testKQ(mang, ex);
    }
    @Test
    public void test10() {
        System.out.println("bai test 10");
        double[] mang = bai15.giaiPhuongTrinhBac2(2, -5, -4);
        double ex = -0.637;
        testKQ(mang, ex);
    }
}
