/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai15_buitruongminhtuan.bai15_3;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TestLuong {
    bai15_buitruongminhtuan.bai15_3 bai15=new bai15_3();
    public TestLuong() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void luong1() {
        double ex=3041000;
        double ac=bai15.tinhLuong(2.34, 1150000, 100000, 250000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong2() {
        double ex=3800000;
        double ac=bai15.tinhLuong(3, 1150000, 150000, 250000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong3() {
        double ex=4329500;
        double ac=bai15.tinhLuong(3.33, 1150000, 200000, 300000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong4() {
        double ex=4800000;
        double ac=bai15.tinhLuong(3.66, 1150000, 300000, 300000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong5() {
        double ex=5338500;
        double ac=bai15.tinhLuong(3.99, 1150000, 400000, 350000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong6() {
        double ex=2800000;
        double ac=bai15.tinhLuong(2.22, 1150000, 150000, 150000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong7() {
        double ex=2646000;
        double ac=bai15.tinhLuong(2.04, 1150000, 150000, 150000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong8() {
        double ex=3500000;
        double ac=bai15.tinhLuong(2.67, 1150000, 500000, 450000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong9() {
        double ex=5803000;
        double ac=bai15.tinhLuong(4.22, 1150000, 500000, 450000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    @Test
    public void luong10() {
        double ex=6000000;
        double ac=bai15.tinhLuong(4.55, 1150000, 300000, 500000);
        System.out.println(ac);
        assertEquals(ex, ac,0);
    }
    
}
