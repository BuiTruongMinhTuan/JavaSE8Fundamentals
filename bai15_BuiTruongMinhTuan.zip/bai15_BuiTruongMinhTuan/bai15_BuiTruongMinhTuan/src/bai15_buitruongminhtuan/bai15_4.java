/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai15_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai15_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public double[] giaiPhuongTrinhBac2(int a, int b, int c) {
        double[] nghiemPT = new double[3];
        double delta;
        double x1 = 0;
        double x2 = 0;
        //------------------------------------------------------------------------
        if (a == 0) {
            if (b == 0) {
                if (c == 0) {
                    System.out.println("Phương trình có vô số nghiệm.");
                    nghiemPT[2] = 2;
                } else {
                    System.out.println("Phương trình vô nghiệm. ");
                    nghiemPT[2] = 1;
                }
            } else {
                x1 = (-c) / b;
                System.out.println("Phương trình có nghiệm duy nhất x1 = x2 = " + x1);
                nghiemPT[0] = x1;
                nghiemPT[1] = 0;
                nghiemPT[2] = 0;
            }
        } //------------------------------------------------------------------------
        else {
            delta = Math.pow(b, 2) - (4 * a * c);
            if (delta < 0) {
                System.out.println("Phương trình vô nghiệm.");
                nghiemPT[2] = 1;
            } else if (delta == 0) {
                x1 = -b / (2 * a);
                nghiemPT[0] = x1;
                nghiemPT[1] = 0;
                nghiemPT[2] = 0;
                System.out.println("Phương trình có nghiệm duy nhất x1 = x2 = " + x1);
            } else if (delta > 0) {
                x1 = (-b + Math.sqrt(delta)) / (2 * a);
                x2 = (-b - Math.sqrt(delta)) / (2 * a);
                nghiemPT[0] = x1;
                nghiemPT[1] = x2;
                nghiemPT[2] = 0;
                System.out.println("Phương trình có 2 nghiệm ");
                System.out.println("X1 = " + x1);
                System.out.println("X2 = " + x2);
            }
        }
        return nghiemPT;
    }

}
