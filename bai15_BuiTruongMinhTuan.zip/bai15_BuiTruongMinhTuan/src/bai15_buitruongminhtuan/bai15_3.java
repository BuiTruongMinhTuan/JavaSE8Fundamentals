/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai15_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai15_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public double tinhLuong(double heSoLuong, double luongCoBan, double troCap, double thuong) {
        double luong = heSoLuong * luongCoBan + troCap + thuong;
        return luong;
    }

}
