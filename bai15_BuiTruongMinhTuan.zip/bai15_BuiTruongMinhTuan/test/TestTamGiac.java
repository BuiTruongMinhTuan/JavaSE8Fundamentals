/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai15_buitruongminhtuan.bai15_2;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TestTamGiac {

    bai15_2 bai15 = new bai15_2();

    public TestTamGiac() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tg1() {
        boolean ac = bai15.laTamGiac(1, 2, 4);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg2() {
        boolean ac = bai15.laTamGiac(2, 3, 4);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg3() {
        boolean ac = bai15.laTamGiac(3, 1, 5);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg4() {
        boolean ac = bai15.laTamGiac(4, 5, 6);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg5() {
        boolean ac = bai15.laTamGiac(10, 5, 20);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg6() {
        boolean ac = bai15.laTamGiac(1, 1, 1);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg7() {
        boolean ac = bai15.laTamGiac(2, 1, 4);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg8() {
        boolean ac = bai15.laTamGiac(5, 10, 8);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg9() {
        boolean ac = bai15.laTamGiac(6, 3, 10);
        System.out.println(ac);
        assertTrue(ac);
    }

    @Test
    public void tg10() {
        boolean ac = bai15.laTamGiac(2, 4, 5);
        System.out.println(ac);
        assertTrue(ac);
    }

}
