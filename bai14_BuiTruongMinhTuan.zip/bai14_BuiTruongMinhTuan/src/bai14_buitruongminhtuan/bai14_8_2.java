/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_8_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public static int doiSangNhiPhan(String sTemp) {
        String soNhiPhan = new StringBuffer(sTemp).reverse().toString();
        int temp;
        int soThapPhan = 0;
        for (int i = 0; i < soNhiPhan.length(); i++) {

            temp = soNhiPhan.charAt(i);

            if (temp == '1') {
                int soTemp = 1;
                //System.out.println(i);
                for (int j = 0; j < i; j++) {

                    soTemp *= 2;
                    //System.out.println(soTemp);
                }
                soThapPhan += soTemp;
            }

        }
        System.out.println("Nhap vao so thap phan:" + soThapPhan);
        return soThapPhan;
    }

}
