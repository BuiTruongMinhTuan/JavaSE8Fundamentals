/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_7_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public static int timSoXHNN(int[][] mangHaiChieu) {
        int[] mangMoiChieu = new int[mangHaiChieu.length * mangHaiChieu[0].length];
        int dem = 0;
        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                mangMoiChieu[dem] = mangHaiChieu[i][j];
                dem++;
            }
        }
        int soSoSanh = 0;
        int soLanXH = 1;
        int soXuatNhieuNhat = 0;
        int soLanHXNhieuNhat = 1;

        for (int i = 0; i < mangMoiChieu.length; i++) {
            soLanXH = 1;
            soSoSanh = 0;
            for (int j = i + 1; j < mangMoiChieu.length - 1; j++) {
                if (mangMoiChieu[i] == mangMoiChieu[j]) {
                    soSoSanh = mangMoiChieu[i];
                    soLanXH++;
                    if (soLanHXNhieuNhat < soLanXH) {
                        soLanHXNhieuNhat = soLanXH;
                        soXuatNhieuNhat = soSoSanh;
                    }

                }
            }

        }
        System.out.println("so xuat hien nhieu nhat: " + soXuatNhieuNhat);

        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                if (mangHaiChieu[i][j] == soXuatNhieuNhat) {
                    System.out.println("vi tri: " + i + " " + j + "  ");
                }
            }
        }
        return soXuatNhieuNhat;
    }
}
