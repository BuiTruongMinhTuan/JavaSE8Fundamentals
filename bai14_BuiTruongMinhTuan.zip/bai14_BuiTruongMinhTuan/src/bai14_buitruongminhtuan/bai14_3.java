/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static boolean timX(int x, int[] a) {
        boolean flag= false;
        for (int i = 0; i < a.length; i++) {
            if (x == a[i]) {
                flag = true;
                break;
            }
            else
                flag = false;
        }
        return flag;
    }
}
