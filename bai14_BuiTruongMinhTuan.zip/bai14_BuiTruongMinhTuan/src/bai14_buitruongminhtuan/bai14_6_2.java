/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_6_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static String doiNhiPhan(int n) {
        String S = "";
        //doi Nhi Phan
        for (; n > 0; n = n / 2) {
            S += n % 2;
        }
        String reverse= new StringBuffer(S).reverse().toString();
        return reverse;
    }
}
