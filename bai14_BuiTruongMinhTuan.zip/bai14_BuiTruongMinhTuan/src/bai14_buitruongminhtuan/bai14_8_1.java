/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_8_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static int tinhTong(int x)
    {
        int tong = 0;
        boolean temp =true;
        
             
            for (int i = 2; i <= x; i++) {
                temp = true;
                for (int j = 2; j <=i/2; j++) {
                    if (i % j == 0) {
                        temp=false;
                        break;
                    }
                
                }
                if (temp) {
                    System.out.println(i);
                    tong += i;

                }

            }
            System.out.println("ket qua tong cac so nguyen to tu 1-:"+x +" la"+ tong);
            return tong;
    }
}
