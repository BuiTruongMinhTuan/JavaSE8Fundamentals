/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai14_9_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static int[] timSoTongBang8(int[]mang)
    {
        int[]mang1=new int[2];
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[i] + mang[j] == 8) {
                    System.out.print(mang[i] + " & " + mang[j] + " ");
                    mang1[0]=mang[i];
                    mang1[1]=mang[j];
                }
            }
        }
        return mang1;
    }
}
