/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bai14_buitruongminhtuan.Bai14_BuiTruongMinhTuan;

/**
 *
 * @author hocvien
 */
public class bai14_1 {
    
    public bai14_1() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test14_1_01() {
        double ex = 125;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(3, 2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_1_02() {
        double ex = 34.1;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(2, -2.2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_1_03() {
        double ex = 1;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(0, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_1_04() {
        double ex = 1;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(-1, -1);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_1_05() {
        double ex = 1;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(0, -100);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_1_06() {
        double ex = 1200;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(3, 3);
        assertEquals(ex, ac, 0.01);
    }
    @Test   
    public void Test14_1_07() {
        double ex = 430;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(2, -4.44444);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_1_08() {
        double ex = 3239971;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(3, -12.123213);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_1_09() {
        double ex = 7384;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(5, -2.22222);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_1_10() {
        double ex = 445160;
        double ac = Bai14_BuiTruongMinhTuan.tinhS(4, -4.983);
        assertEquals(ex, ac, 0.01);
    }
}
