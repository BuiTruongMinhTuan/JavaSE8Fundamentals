/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author hocvien
 */
public class bai14_8_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static double tinhGiaiThuc(int soGiaiThua)
    {
        double giaiThua = 1;
        System.out.print(soGiaiThua + "!= ");
        for (int i = 1; i <= soGiaiThua; i++) {
            giaiThua *= i;
            System.out.print(i + " ");
            if (i == soGiaiThua) {
                System.out.print("= ");
            } else {
                System.out.print("x ");
            }
        }
        System.out.print(giaiThua);
        System.out.println();
        return giaiThua;
    }
    
}
