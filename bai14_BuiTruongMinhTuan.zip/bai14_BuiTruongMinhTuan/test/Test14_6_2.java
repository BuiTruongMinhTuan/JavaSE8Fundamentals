/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author hocvien
 */
public class Test14_6_2 {
    
    public Test14_6_2() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
      @Test
    public void Bai14_6_DoiNP_01() {
        String ex = "1010";
        String ac = bai14_6_2.doiNhiPhan(10);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_02() {
        String ex = "10111";
        String ac = bai14_6_2.doiNhiPhan(23);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_03() {
        String ex = "100011";
        String ac = bai14_6_2.doiNhiPhan(35);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_04() {
        String ex = "11";
        String ac = bai14_6_2.doiNhiPhan(3);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_05() {
        String ex = "1100100";
        String ac = bai14_6_2.doiNhiPhan(100);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_06() {
        String ex = "100100";
        String ac = bai14_6_2.doiNhiPhan(37);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_07() {
        String ex = "10111";
        String ac = bai14_6_2.doiNhiPhan(21);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_08() {
        String ex = "100101101";
        String ac = bai14_6_2.doiNhiPhan(300);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_09() {
        String ex = "11011111";
        String ac = bai14_6_2.doiNhiPhan(222);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_6_DoiNP_6_10() {
        String ex = "1100111";
        String ac = bai14_6_2.doiNhiPhan(102);
        assertEquals(ex ,ac);
    }
}
