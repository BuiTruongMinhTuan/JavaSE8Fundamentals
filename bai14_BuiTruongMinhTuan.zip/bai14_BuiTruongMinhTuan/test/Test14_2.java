/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import bai14_buitruongminhtuan.bai14_2;

/**
 *
 * @author hocvien
 */
public class Test14_2 {
    
    public Test14_2() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test14_2_01() {
        double ex = 370;
        double ac = bai14_2.tinhA(3, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_02() {
        double ex = 77.89;
        double ac = bai14_2.tinhA(2, -2.2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_2_03() {
        double ex = 1;
        double ac = bai14_2.tinhA(0, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_2_04() {
        double ex = 1;
        double ac = bai14_2.tinhA(-1, -1);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void Test14_2_05() {
        double ex = 1;
        double ac = bai14_2.tinhA(0, -100);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_06() {
        double ex = 215;
        double ac = bai14_2.tinhA(0, -100);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_07() {
        double ex = 900;
        double ac = bai14_2.tinhA(2, -4.44444);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_08() {
        double ex = 6610430;
        double ac = bai14_2.tinhA(3, -12.123213);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_09() {
        double ex = 36897;
        double ac = bai14_2.tinhA(5, -2.22222);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void Test14_2_10() {
        double ex = 1090357;
        double ac = bai14_2.tinhA(4, -4.983);
        assertEquals(ex, ac, 0.01);
    }
}
