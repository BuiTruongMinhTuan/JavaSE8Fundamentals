/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author hocvien
 */
public class Test14_9_3 {
    
    public Test14_9_3() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int[][]mang={{1,2,3},{2,4,8},{3,8,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertTrue(ac);
    }
    @Test
    public void test2() {
        int[][]mang={{3,2,5},{2,4,3},{5,3,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertTrue(ac);
    }
    @Test
    public void test3() {
        int[][]mang={{2,1,3},{1,4,4},{3,4,6}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertTrue(ac);
    }
    @Test
    public void test4() {
        int[][]mang={{5,3,4},{3,1,4},{4,4,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertTrue(ac);
    }
    @Test
    public void test5() {
        int[][]mang={{0,1,2},{1,1,0},{2,0,2}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertTrue(ac);
    }
    @Test
    public void test6() {
        int[][]mang={{1,2,1},{2,4,8},{3,8,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertFalse(ac);
    }
    @Test
    public void test7() {
        int[][]mang={{3,2,3},{2,4,3},{5,3,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertFalse(ac);
    }
    @Test
    public void test8() {
        int[][]mang={{2,1,2},{1,4,4},{3,4,6}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertFalse(ac);
    }
    @Test
    public void test9() {
        int[][]mang={{5,3,5},{2,1,4},{4,4,5}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertFalse(ac);
    }
    @Test
    public void test10() {
        int[][]mang={{0,1,0},{1,1,0},{2,0,2}};
        boolean ac=bai14_9_3.ktDoiXungCheo(mang);
        assertFalse(ac);
    }
}
