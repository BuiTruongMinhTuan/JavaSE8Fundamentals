/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author hocvien
 */
public class Test14_9_2 {
    
    public Test14_9_2() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int[] mang = {1, 4, 6, 7, 8};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {1, 7};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test2() {
        int[] mang = {10,3,23,5,76};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {3, 5};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test3() {
        int[] mang = {2,8,1,66,6};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {2, 6};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test4() {
        int[] mang = {26,3,5,23,66};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {3,5};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test5() {
        int[] mang = {4,5,2,3,36};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {5,3};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test6() {
        int[] mang = {1,4,6,7,8};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {6,1};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test7() {
        int[] mang = {10,3,23,5,76};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {10,23};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test8() {
        int[] mang = {2,8,1,66,6};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {8,1};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test9() {
        int[] mang = {26,3,5,23,66};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {66,26};
        assertArrayEquals(ex, ac);
    }
    @Test
    public void test10() {
        int[] mang = {4,5,2,3,36};
        int[] ac = bai14_9_2.timSoTongBang8(mang);
        int[] ex = {5,4};
        assertArrayEquals(ex, ac);
    }
}
