/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author hocvien
 */
public class Test14_8_2 {

    public Test14_8_2() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int ac = bai14_8_2.doiSangNhiPhan("1111");
        int ex = 15;
        assertEquals(ac, ex);
    }
    @Test
    public void test2() {
        int ac = bai14_8_2.doiSangNhiPhan("1000");
        int ex = 8;
        assertEquals(ac, ex);
    }
    @Test
    public void test3() {
        int ac = bai14_8_2.doiSangNhiPhan("110001");
        int ex = 49;
        assertEquals(ac, ex);
    }
    @Test
    public void test4() {
        int ac = bai14_8_2.doiSangNhiPhan("100100");
        int ex = 36;
        assertEquals(ac, ex);
    }
    @Test
    public void test5() {
        int ac = bai14_8_2.doiSangNhiPhan("11111");
        int ex = 31;
        assertEquals(ac, ex);
    }
    @Test
    public void test6() {
        int ac = bai14_8_2.doiSangNhiPhan("1111");
        int ex = 12;
        assertEquals(ac, ex);
    }
    @Test
    public void test7() {
        int ac = bai14_8_2.doiSangNhiPhan("1000");
        int ex = 6;
        assertEquals(ac, ex);
    }
    @Test
    public void test8() {
        int ac = bai14_8_2.doiSangNhiPhan("110001");
        int ex = 44;
        assertEquals(ac, ex);
    }
    @Test
    public void test9() {
        int ac = bai14_8_2.doiSangNhiPhan("100100");
        int ex = 40;
        assertEquals(ac, ex);
    }
    @Test
    public void test10() {
        int ac = bai14_8_2.doiSangNhiPhan("11111");
        int ex = 130;
        assertEquals(ac, ex);
    }
}
