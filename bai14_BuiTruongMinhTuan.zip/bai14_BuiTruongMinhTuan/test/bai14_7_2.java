/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author hocvien
 */
public class bai14_7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public static boolean timX(int[] mangInt, int timX) {
        boolean ktX = false;
        for (int i : mangInt) {
            if (i == timX) {
                ktX = true;
                break;
            } else {
                ktX = false;
            }
        }
        return ktX;
    }
}
