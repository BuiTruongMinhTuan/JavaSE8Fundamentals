/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author hocvien
 */
public class bai14_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static String tinhNamAmLich(int year) {
	return tinhCan(year) + " " + tinhChi(year);
    }
    public static String tinhCan(int year) {
        String can = "";
        int layDu = year % 10;
        switch (layDu) {
            case 0:
                can = "Canh";
                break;
            case 1:
                can = "Tan";
                break;
            case 2:
                can = "Nham";
                break;
            case 3:
                can = "Quy";
                break;
            case 4:
                can = "Giap";
                break;
            case 5:
                can = "At";
                break;
            case 6:
                can = "Binh";
                break;
            case 7:
                can = "Dinh";
                break;
            case 8:
                can = "Mau";
                break;
            case 9:
                can = "Ky";
                break;
        }
        return can;
    }

    public static String tinhChi(int year) {
        String chi = "";
        int layDu = year % 12;
        switch (layDu) {
            case 0:
                chi = "Than";
                break;
            case 1:
                chi = "Dau";
                break;
            case 2:
                chi = "Tuat";
                break;
            case 3:
                chi = "Hoi";
                break;
            case 4:
                chi = "Ty";
                break;
            case 5:
                chi = "Suu";
                break;
            case 6:
                chi = "Dan";
                break;
            case 7:
                chi = "Mao";
                break;
            case 8:
                chi = "Thin";
                break;
            case 9:
                chi = "Ty";
                break;
            case 10:
                chi = "Ngo";
                break;
            case 11:
                chi = "Mui";
                break;
        }
        return chi;
    }
}
