/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author hocvien
 */
public class bai14_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
      public static boolean ktSoNT(int n) {
        boolean flag = true;
        if (n < 2) {
            flag = false;
        } else {
            for (int i = 2; i < n; i++) {
                if (n % i == 0) {
                    flag = false;
                }
            }
        }
        return flag;
    }
}
