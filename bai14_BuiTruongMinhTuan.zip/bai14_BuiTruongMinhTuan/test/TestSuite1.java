/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author hocvien
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({Test14_5.class, Test14_2.class, Test14_7_3.class, Test14_9_3.class, Test14_8_3.class, Test14_6_2.class, Test14_8_2.class, Test14_9_2.class, Test14_6.class, Test14_7_2.class, Test14_3.class, Test14_8_1.class, Test14_4.class, Test14_9_1.class})
public class TestSuite1 {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
