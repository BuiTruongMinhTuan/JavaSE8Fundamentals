/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so thap phan:");
        int soThapPhan=1;
        soThapPhan = Integer.parseInt(input.readLine());
        
        String sTemp = "";
        
        for(;soThapPhan!=0;soThapPhan/=2)
        {
            sTemp+=soThapPhan%2;
        }
//        while (soThapPhan!=0) {
//            
//            sTemp+=soThapPhan%2;
//            soThapPhan/=2;
//        
//        }
        String soNhiPhan=new StringBuffer(sTemp).reverse().toString();
        System.out.println("so thap phan: "+soNhiPhan);
    }
    
}
