/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_1_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        float tich = 1;
        System.out.println("Nhap vao so lan lap n:");
        int n = Integer.parseInt(input.readLine());
        System.out.println("Nhap vao so x:");
        int x = Integer.parseInt(input.readLine());

        if (n == 0) {
            System.out.println("ket qua la :" + tich);
        } else {
//            for (int i = 1; i <= n; i++) {
//                tich *= (x * x + 1);
//            }
//            System.out.println("ket qua la :" + tich);
            int i = 1;
            while (i <= n) {
              tich *= (x * x + 1);
              i++;
            }
            System.out.println("ket qua la :" + tich);
        }
    }
    
}
