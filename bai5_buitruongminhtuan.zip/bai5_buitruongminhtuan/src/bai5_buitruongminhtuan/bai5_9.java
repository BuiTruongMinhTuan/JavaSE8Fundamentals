/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap so can giai thua:");
        int soGiaiThua = Integer.parseInt(input.readLine());
        int giaiThua = 1;
        System.out.print(soGiaiThua + "!= ");
        for (int i = 1; i <= soGiaiThua; i++) {
            giaiThua *= i;
            System.out.print(i + " ");
            if (i == soGiaiThua) {
                System.out.print("= ");
            } else {
                System.out.print("x ");
            }
        }
        System.out.print(giaiThua);
        
        if (soGiaiThua % 2 == 0) {
            System.out.println("");
            System.out.print(soGiaiThua + "!!= ");
            giaiThua=1;
            for (int i = 1; i <= soGiaiThua; i++) {
                if (i % 2 == 0) {
                    giaiThua *= i;
                    System.out.print(i + " ");
                    if (i == soGiaiThua) {
                        System.out.print("= ");
                    } else {
                        System.out.print("x ");
                    }
                }
            }
            System.out.print(giaiThua);
            System.out.println("");
        }
        else
        {
            System.out.println("");
            System.out.print(soGiaiThua + "!!= ");
            giaiThua=1;
            for (int i = 1; i <= soGiaiThua; i++) {
                if (i % 2 != 0) {
                    giaiThua *= i;
                    System.out.print(i + " ");
                    if (i == soGiaiThua) {
                        System.out.print("= ");
                    } else {
                        System.out.print("x ");
                    }
                }
            }
            System.out.print(giaiThua);
            System.out.println("");
        }

    }

}
