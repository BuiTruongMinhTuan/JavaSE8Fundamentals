/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap vao so x:");
        int x = Integer.parseInt(input.readLine());
        int tong = 0;
        boolean temp = true;

//            for (int i = 2; i <= x; i++) {
//                temp = true;
//                for (int j = 2; j <=i/2; j++) {
//                    if (i % j == 0) {
//                        temp=false;
//                        break;
//                    }
//                
//                }
//                if (temp) {
//                    System.out.println(i);
//                    tong += i;
//
//                }
//
//            }
        int i = 2;
        while (i <= x) {
            temp = true;
            for (int j = 2; j <= i / 2; j++) {
                if (i % j == 0) {
                    temp = false;
                    break;
                }

            }
            if (temp) {
                System.out.println(i);
                tong += i;

            }
            i++;
        }
        System.out.println("ket qua la :" + tong);
    }

}
