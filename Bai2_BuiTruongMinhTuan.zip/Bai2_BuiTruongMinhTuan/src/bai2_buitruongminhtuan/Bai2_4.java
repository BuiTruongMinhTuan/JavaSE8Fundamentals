/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new  InputStreamReader(System.in));
        System.out.println("nhap vao dien tich hinh tron");
        float dientich= Integer.parseInt(input.readLine());
        final float pi=3.14f;
        double banKinh = Math.sqrt(dientich/pi);
        System.out.println("ban kinh:"+String.format("%.0f", banKinh));
 
    }
    
}
