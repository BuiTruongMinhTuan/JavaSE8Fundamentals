/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new  InputStreamReader(System.in));
        System.out.println("nhap lai suat 1 nam");
        float laiSuat= Integer.parseInt(input.readLine());
        System.out.println("nhap so tien gui");
        float soTienGui= Integer.parseInt(input.readLine());
        System.out.println("nhap so thang gui");
        float soThangGui= Integer.parseInt(input.readLine());
        float tienLai=(soThangGui*soTienGui)*(laiSuat/12/100);
        float tongSoTien= soTienGui+tienLai;
       
        System.out.println("tien lai:"+String.format("%.0f", tienLai));
        System.out.println("tong so tien :"+String.format("%.0f", tongSoTien));
    }
    
}
