/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new  InputStreamReader(System.in));
        System.out.println("nhap ten ngoai te");
        String tenNgoaiTe= input.readLine();
        System.out.println("nhap ti gia");
        float tiGia= Integer.parseInt(input.readLine());
        System.out.println("nhap so ngoai te");
        float soNgoaiTe= Integer.parseInt(input.readLine());
        float thanhTien=tiGia*soNgoaiTe;
       
        System.out.println("So tien ban doi tu:"+tenNgoaiTe+"sang VND");
        System.out.println("thanh tien :"+String.format("%.0f", thanhTien));
    }
    
}
