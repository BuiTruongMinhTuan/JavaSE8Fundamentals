/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new  InputStreamReader(System.in));
        System.out.println("nhap so san pham");
        int soSP= Integer.parseInt(input.readLine());
        System.out.println("nhap tien cong 1 san pham");
        float tienCong= Integer.parseInt(input.readLine());
        System.out.println("nhap tien thuong");
        float soTienThuong= Integer.parseInt(input.readLine());
        System.out.println("nhap so con");
        int soCon= Integer.parseInt(input.readLine());
        float phuCap=soCon*200000;
        float tienluong=soSP*tienCong+phuCap;
        float thucLinh=tienluong+soTienThuong+phuCap;
        
        System.out.println("tien luong :"+String.format("%.0f", tienluong));
        System.out.println("phu cap :"+String.format("%.0f", phuCap));
        System.out.println("thuc linh :"+String.format("%.0f", thucLinh));
    }
    
}
