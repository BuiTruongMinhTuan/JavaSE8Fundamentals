/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new  InputStreamReader(System.in));
        System.out.println("nhap ban kinh duong tron");
        float banKinh= Integer.parseInt(input.readLine());
        final float pi=3.14f;
        float chuvi= pi * 2* banKinh;
        float dienTich = banKinh*banKinh*pi;
        System.out.println("chu vi:"+String.format("%.0f", chuvi));
        System.out.println("dien tich:"+String.format("%.0f", dienTich));
        
    }
    
}
