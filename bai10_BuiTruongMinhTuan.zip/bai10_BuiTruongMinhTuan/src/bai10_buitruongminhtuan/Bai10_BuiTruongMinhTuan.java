/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_buitruongminhtuan;

enum PhepToan {
    Cong, Tru, Nhan, Chia;

    double tinhToan(double a, double b) {
        switch (this) {
            case Cong:
                return a + b;
            case Tru:
                return a - b;
            case Nhan:
                return a * b;
            case Chia:
                return a / b;
                default:
                    throw  new AssertionError("Khong khac dinh toan tu "+this);
        }
    }
    
}

public class Bai10_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double ketQua= PhepToan.Cong.tinhToan(3, 0);
        System.out.println("phep cong : "+ketQua);
         ketQua= PhepToan.Tru.tinhToan(3, 8);
        System.out.println("phep tru : "+ketQua);
         ketQua= PhepToan.Nhan.tinhToan(3, 2);
        System.out.println("phep nhan : "+ketQua);
        ketQua= PhepToan.Chia.tinhToan(5, 2);
        System.out.println("phep chia : "+ketQua);
        
    }

}
