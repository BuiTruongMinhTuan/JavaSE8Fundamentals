/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

enum OanTuTi {
    sKeo, tBua, pBao;

}

public class bai10_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        troChoi();
    }

    static int PCChon() {
        Random random = new Random();
        int soRanDom = 0;
        soRanDom = random.nextInt(3);
        return soRanDom;
    }

    static void troChoi() throws IOException {
        boolean batDau = false;
        System.out.println("nhan S de bat dau tro choi:");
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        String ktBatDau = input.readLine();
        if (ktBatDau.equalsIgnoreCase("s")) {
            batDau = true;
        }
        int vongChoi = 1;
        int diemNguoiChoi = 0;
        int diemPC = 0;
        while (batDau) {
            System.out.println("Chao ban den voi tro choi Oan Tu Ti");
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("Vong choi thu " + vongChoi);
            System.out.println("Moi ban chon S la Keo\t T la bua\t P la bao\t Q de thoat:");
            String nguoiChoiChon = input.readLine();
            int soNguoiChoiDaChon = 0;
            if (nguoiChoiChon.equalsIgnoreCase("q")) {
                System.out.println("Ket thuc tro choi:");
                System.out.println("Diem nguoi choi: " + diemNguoiChoi);
                System.out.println("Diem PC: " + diemPC);
                batDau = false;
                break;
            } else if (nguoiChoiChon.equalsIgnoreCase("s")) {
                System.out.println("Ban da chon: " + OanTuTi.sKeo.name());
                soNguoiChoiDaChon = 0;
            } else if (nguoiChoiChon.equalsIgnoreCase("t")) {
                System.out.println("Ban da chon: " + OanTuTi.tBua.name());
                soNguoiChoiDaChon = 1;
            } else if (nguoiChoiChon.equalsIgnoreCase("p")) {
                System.out.println("Ban da chon: " + OanTuTi.pBao.name());
                soNguoiChoiDaChon = 2;
            } else {
                System.out.println("ban nhap sai rui vui long nhap lai");
                continue;
            }

            int soPCChon = PCChon();
            if (soPCChon == 0) {
                System.out.println("PC da chon: " + OanTuTi.sKeo.name());
            } else if (soPCChon == 1) {
                System.out.println("PC da chon: " + OanTuTi.tBua.name());
            } else {
                System.out.println("PC da chon: " + OanTuTi.pBao.name());
            }
            int nguoiThang = ktThangThua(soNguoiChoiDaChon, soPCChon);

            if (nguoiThang == 0) {
                System.out.println("Hai ban Hoa");
            } else if (nguoiThang == 1) {
                System.out.println("Ban thang");
                diemNguoiChoi++;
            } else {
                System.out.println("PC thang");
                diemPC++;
            }
            System.out.println("diem nguoi choi la: " + diemNguoiChoi);
            System.out.println("diem PC la: " + diemPC);
            if (diemNguoiChoi == 5 || diemPC == 5) {
                System.out.println("Tro Choi Ket Thuc!");
                System.out.println("Diem nguoi choi: " + diemNguoiChoi);
                System.out.println("Diem PC: " + diemPC);
                if (diemNguoiChoi > diemPC) {
                    System.out.println("Nguoi Choi Chien Thang");
                } else {
                    System.out.println("PC Chien Thang");
                }
                batDau = false;
            }
            vongChoi++;
        }
    }

    static int ktThangThua(int soNguoiChoiChon, int soPCChon) {
        int nguoiThang = 0;
        if (soNguoiChoiChon == soPCChon) {
            nguoiThang = 0;
        } else if (soNguoiChoiChon == 2 && soPCChon == 0) {
            nguoiThang = 2;

        } else if (soNguoiChoiChon == 0 && soPCChon == 2) {
            nguoiThang = 1;
        } else if (soNguoiChoiChon > soPCChon) {
            nguoiThang = 1;
        } else {
            nguoiThang = 2;
        }
        return nguoiThang;
    }
}
