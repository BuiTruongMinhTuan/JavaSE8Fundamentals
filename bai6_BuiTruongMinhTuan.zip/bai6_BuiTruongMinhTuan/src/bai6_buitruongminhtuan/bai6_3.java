/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai6_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so n phan tu cu mang:");
        int readNum = Integer.parseInt(input.readLine());
        int[] anArray = new int[readNum];
        System.out.println("Nhap vao gia tri cua mang:");

        for (int i = 0; i < anArray.length; i++) {
            anArray[i] = Integer.parseInt(input.readLine());
        }
        System.out.println("mang ban da :");
        for (int i = 0; i < anArray.length; i++) {
            System.out.print(anArray[i] + " ");
        }
        System.out.println("\n");
        boolean ktTangDan = false;
        boolean ktGiamDan = false;
        for (int i = 0; i < anArray.length - 1; i++) {
            if (anArray[i] > anArray[i + 1]) {
                ktGiamDan = false;
            } else {
                ktGiamDan = true;
                break;
            }
        }

        for (int i = 0; i < anArray.length - 1; i++) {
            if (anArray[i] < anArray[i + 1]) {
                ktTangDan = false;
            } else {
                ktTangDan = true;
                break;
            }
        }
        if (ktGiamDan) {
            System.out.println("mang khong theo thu tu giam dan");
        } else {
            System.out.println("mang theo thu tu giam dan");
        }

        if (ktTangDan) {
            System.out.println("mang khong theo thu tu tang dan");
        } else {
            System.out.println("mang theo thu tu tang dan");
        }

        System.out.println("mang ban da :");
        for (int i = 0; i < anArray.length; i++) {
            System.out.print(anArray[i] + " ");
        }
        System.out.println("\n");
        for (int i = 0; i < anArray.length; i++) {
            if (anArray[i] % 10 == 6 || anArray[i] == 6) {
                System.out.println("phan tu thu " + i + " co so tan cung la 6:" + anArray[i]);
                break;
            }
        }
    }

}
