/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_buitruongminhtuan;

import com.sun.org.apache.bcel.internal.generic.AALOAD;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai6_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao so n so dong mang:");
        int soDong = Integer.parseInt(input.readLine());
        System.out.println("Nhap vao so m so cot mang:");
        int soCot = Integer.parseInt(input.readLine());
        int[][] mangHaiChieu = new int[soDong][soCot];
        int[] mangMoiChieu = new int[soDong * soCot];
        int max = 0;
        int min = 0;
        int dem = 0;
        System.out.println("Nhap vao gia tri cua mang:");
        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                System.out.println("vi tri:" + i + " " + j);
                mangHaiChieu[i][j] = Integer.parseInt(input.readLine());
                mangMoiChieu[dem] = mangHaiChieu[i][j];
                dem++;
                if (i == 0 && j == 0) {
                    max = min = mangHaiChieu[i][j];
                }
                max = Math.max(max, mangHaiChieu[i][j]);
                min = Math.min(min, mangHaiChieu[i][j]);
            }
        }

        int soChan = 0;
        int soLe = 0;
        int tongSoChan = 0;
        int tongSoLe = 0;
        System.out.println("mang ban da nhap:");
        for (int[] dong : mangHaiChieu) {
            for (int i : dong) {
                System.out.print(i + " ");
                if (i % 2 == 0) {
                    soChan++;
                    tongSoChan += i;
                } else {
                    soLe++;
                    tongSoLe += i;
                }

            }
            System.out.print("\n");
        }
        int tbChan = 0;

        if (soChan != 0) {
            tbChan = tongSoChan / soChan;
        }
        System.out.println("so chan trong mang: " + soChan + " gia tri trung binh so chan: " + tbChan);
        int tbLe = 0;
        if (soLe != 0) {
            tbLe = tongSoLe / soLe;
        }

        System.out.println("so le trong mang: " + soLe + " gia tri trung binh so chan: " + tbLe);

        System.out.println("so lon nhat trong mang: " + max);
        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                if (mangHaiChieu[i][j] == max) {
                    System.out.println("vi tri:" + i + " " + j);
                }
            }
        }

        System.out.println("so nho nhat trong mang: " + min);
        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                if (mangHaiChieu[i][j] == min) {
                    System.out.println("vi tri:" + i + " " + j);
                }
            }
        }

        boolean soAm = false;
        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                if (mangHaiChieu[i][j] < 0) {
                    soAm = true;
                    break;
                }
            }
        }
        if (soAm) {
            System.out.println("mang nhap co so am");
        } else {
            System.out.println("mang nhap  khong co so am");
        }

        int soSoSanh = 0;
        int soLanXH = 1;
        int soXuatNhieuNhat = 0;
        int soLanHXNhieuNhat = 1;

        for (int i = 0; i < mangMoiChieu.length; i++) {
            soLanXH = 1;
            soSoSanh = 0;
            for (int j = i + 1; j < mangMoiChieu.length - 1; j++) {
                if (mangMoiChieu[i] == mangMoiChieu[j]) {
                    soSoSanh = mangMoiChieu[i];
                    soLanXH++;
                    if (soLanHXNhieuNhat < soLanXH) {
                        soLanHXNhieuNhat = soLanXH;
                        soXuatNhieuNhat = soSoSanh;
                    }

                }
            }

        }
        System.out.println("so xuat hien nhieu nhat: " + soXuatNhieuNhat);

        for (int i = 0; i < mangHaiChieu.length; i++) {
            for (int j = 0; j < mangHaiChieu[i].length; j++) {
                if (mangHaiChieu[i][j] == soXuatNhieuNhat) {
                    System.out.println("vi tri: " + i + " " + j + "  ");
                }
            }
        }
    }
}
