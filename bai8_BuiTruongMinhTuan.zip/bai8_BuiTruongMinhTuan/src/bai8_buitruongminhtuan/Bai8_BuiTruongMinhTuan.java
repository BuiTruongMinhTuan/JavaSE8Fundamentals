/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai8_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Nhâp số nguyên cần kiểm tra: ");
        try {
            int soNguyen = scan.nextInt();
            kiemTraNguyenTo(soNguyen);
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }

    }

    static void kiemTraNguyenTo(int soNguyenTo) {

        if (soNguyenTo < 0) {
            throw new ArithmeticException("Số cần kiểm tra không đươc âm");
        }
        String s = "Đây là số nguyên tố";
        if (soNguyenTo < 2) {
            s = "Không phải là số nguyên tố";
        } else if (soNguyenTo > 2) {
            int i;
            int temp = (int) Math.sqrt(soNguyenTo);
            for (i = 2; i <= temp; i++) {
                if (soNguyenTo % i == 0) {
                    s = "Không phải là số nguyên tố";
                }

            }
        }
        System.out.println(s);
    }

}
