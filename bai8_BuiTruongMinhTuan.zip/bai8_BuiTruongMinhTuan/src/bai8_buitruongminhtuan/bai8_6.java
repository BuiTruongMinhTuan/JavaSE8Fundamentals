/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai8_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Từ số: ");
            int tuSo = scan.nextInt();
            System.out.println("Đến số: ");
            int denSo = scan.nextInt();

            inBangCuuChuong(tuSo, denSo);
        } catch (InputMismatchException e) {
            System.out.println("Đinh dạng nhập vào không đúng");
        } catch (NumberFormatException e) {
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e) {
            System.err.println(e.getMessage());
        }
    }

    static void inBangCuuChuong(int tuSo, int denSo) {

        if (tuSo < 0) {
            throw new ArithmeticException("Số nhập phải lớn hơn hoặc bằng 0");
        }
        if (denSo < tuSo) {
            throw new ArithmeticException("Số kết thúc phải lớn hơn số bắt đầu");
        }
        String chuoi = "";
        int i, j;
        for (i = 1; i <= 9; i++) {
            for (j = tuSo; j <= denSo; j++) {
                chuoi += String.format("%d x %d = %d\t", j, i, (j * i));
            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }
}
