/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai8_2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Lãi suất một tháng:");
        try {
            double laiSuat = scan.nextDouble();
            System.out.println("Số tiền gữi:");
            int tienGui = scan.nextInt();
            System.out.println("Số tháng:");
            int soThang = scan.nextInt();

            double tienLai = tinhLai(laiSuat, tienGui, soThang);
            System.out.println(String.format("Tiền lãi: %.2f", tienLai));
            System.out.println(String.format("Tổng vốn và lãi l:à %.2f", tinhTongTien(tienLai, tienGui)));
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e) {
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    static double tinhLai(double laiSuat, int tienGui, int soThang) {
        if (laiSuat < 0 || tienGui < 0 || soThang < 0) {
            throw new ArithmeticException("Lãi suất tiền gữi số tháng phải là số dương");
        }
        double tienLai = 0;
        tienLai = (tienGui * soThang) * (laiSuat / 12 / 100);
        return tienLai;
    }

    static double tinhTongTien(double tienLai, int tienGui) {

        if (tienLai < 0 || tienGui < 0) {
            throw new ArithmeticException("Tien lãi và tiền gữi phải là số dương");
        }
        double tongTien = 0;
        tongTien = tienGui + tienLai;
        return tongTien;
    }

}
