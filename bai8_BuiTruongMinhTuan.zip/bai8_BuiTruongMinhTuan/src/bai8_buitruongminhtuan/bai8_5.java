/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai8_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Xin nhap so nhi phan muon doi: ");
            int so = scan.nextInt();

            System.out.println("Kết quả là: " + doiSangThapPhan(so));
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e) {
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    static int doiSangThapPhan(int so) {

        if (so < 0) {
            throw new ArithmeticException("Số cần đổi phải là số dương");
        }
        String chuoi = String.valueOf(so);
        for (int i = 0; i < chuoi.length(); i++) {

            if (chuoi.charAt(i) != '1' && chuoi.charAt(i) != '0') {
                throw new ArithmeticException("Số cần đổi kí tự chỉ có 0 va 1");
            }
        }
        chuoi = new StringBuffer(String.valueOf(so)).reverse().toString();

        int tong = 0, i;
        for (i = 0; i < chuoi.length(); i++) {
            if (chuoi.charAt(i) == '1') {
                tong += (int) Math.pow(2, i);
            }
        }
        return tong;
    }

}
