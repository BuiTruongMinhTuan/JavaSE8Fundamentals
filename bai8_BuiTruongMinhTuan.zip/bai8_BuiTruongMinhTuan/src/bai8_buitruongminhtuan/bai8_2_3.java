/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai8_2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Nhap chieu cao:");
            double chieuCao = sc.nextDouble();
            System.out.println("Nhap can nang:");
            double canNang = sc.nextDouble();
            double BMI = tinhBMI(chieuCao, canNang);
            System.out.println("BMI = " + BMI + " - Ket luan: " + danhGiaBMI(BMI));
        } catch (ArithmeticException | IllegalArgumentException | NullPointerException e) {

            System.out.println("Loi: " + e.toString());
        }
    }

    static double tinhBMI(double chieuCao, double canNang) {
        return canNang / (chieuCao * chieuCao);
    }

    static String danhGiaBMI(double BMI) {
        if (BMI < 18.5) {
            return "Ban hoi gay";
        } else if (BMI < 24.99) {
            return "Ban binh thuong";
        } else {
            return "Ban thua can";
        }
    }
}
