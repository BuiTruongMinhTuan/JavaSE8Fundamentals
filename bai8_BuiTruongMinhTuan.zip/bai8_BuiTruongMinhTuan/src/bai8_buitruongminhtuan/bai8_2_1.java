package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class bai8_2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Hãy nhập x: ");
            double x = scan.nextDouble();
            System.out.println("Hãy nhập y: ");
            double y = scan.nextDouble();
            double giaTri = tinhToan(x, y);
            System.out.println("Kết quả là: " + String.format("%.1f", tinhToan(x, y)));
        } catch (InputMismatchException | ArithmeticException ex) {
            System.out.println(ex.getMessage());
        }
    }

    static double tinhToan(double x, double y) {

        double tam = 0;

        double mauSo = (2 * x + 7 * y);
        if (mauSo == 0) {
            throw new ArithmeticException("2*x + 7*y không thể bằng 0");
        }

        double tuSo = 5 * x - y;
        tam = tuSo / mauSo;
        if (tam < 0) {
            throw new ArithmeticException("5*x - y / 2*x + 7*y phải lớn hơn hoặc bằng 0");
        }
        return Math.sqrt((tuSo / mauSo));
    }
}
