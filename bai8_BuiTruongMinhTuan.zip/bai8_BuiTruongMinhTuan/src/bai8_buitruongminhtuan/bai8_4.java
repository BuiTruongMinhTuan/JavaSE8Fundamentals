/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_buitruongminhtuan;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai8_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập số cần đổi sang nhị phân: ");
        try {
            int so = scan.nextInt();

            System.out.println(doiSangNhiPhan(so));
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào sai");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    static String doiSangNhiPhan(int so) {
        if (so < 0) {
            throw new ArithmeticException("Số cần đổi phải là số dương");
        }
        String chuoi = "";
        while (so != 0) {
            String temp = String.valueOf(so % 2);
            chuoi += temp;
            so = so / 2;
        }
        chuoi = new StringBuffer(chuoi).reverse().toString();
        return chuoi;
    }

}
