/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai11_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap chuoi sb");
        StringBuilder sb=new StringBuilder(input.readLine());
        System.out.println("nhap chuoi sb1");
        StringBuilder sb1=new StringBuilder(input.readLine());
        System.out.println("nhap chuoi sb2");
        StringBuilder sb2=new StringBuilder(input.readLine());
        System.out.println("nhap chuoi sb3");
        StringBuilder sb3=new StringBuilder(input.readLine());
        System.out.println("nhap chuoi sb4");
        StringBuilder sb4=new StringBuilder(input.readLine());
         System.out.println("nhap vi tri chen");
        int viTriChen=Integer.parseInt(input.readLine());
        System.out.println("nhap vi tri bat dau");
        int viTriBatDau=Integer.parseInt(input.readLine());
        System.out.println("nhap vi tri ket thuc");
        int viTriKetThuc=Integer.parseInt(input.readLine());
        System.out.println("chieu dai chuoi sb1: "+sb1.length());
        System.out.println("chieu dai chuoi sb1: "+sb2.length());
        System.out.println("chieu dai chuoi sb1: "+sb3.length());
        System.out.println("chieu dai chuoi sb1: "+sb4.length());
        System.out.println("chuoi sb sau khi noi chuoi sb1 vao: "+sb.append(sb1));
        System.out.println("chuoi sb sau khi chen chuoi sb2 vao: vi tri "+viTriChen+" "+sb.insert(viTriChen,sb2));
        System.out.println("chuoi sb sau khi xoa: vi tri "+viTriBatDau+"toi "+viTriKetThuc+" "+sb.delete(viTriBatDau,viTriKetThuc));
        System.out.println("chuoi sb sau khi dao nguoc: "+sb.reverse());
    }
    
}
