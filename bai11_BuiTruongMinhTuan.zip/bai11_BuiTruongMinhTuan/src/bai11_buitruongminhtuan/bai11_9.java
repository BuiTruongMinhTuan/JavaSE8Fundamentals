/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai11_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap email:");
        String chuoi = input.readLine();
        String regexp = "[_a-zA-Z0-9-+]+(\\.[a-zA-Z0-9_-]+)*@[a-zA-Z-0-9_]+(\\.[a-zA-Z.]{2,})";
        Pattern pattern = Pattern.compile(regexp);
        Matcher matcher = pattern.matcher(chuoi);
        boolean kt = matcher.matches();
        if (kt) {
            System.out.println("ban nhap dung dinh dang ");
        } else {
            System.out.println("ban sai dinh dang ");
        }
    }
    
    
}
