/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai11_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        StringBuilder chuoiS1;
        StringBuilder chuoiS2;
        StringBuilder chuoiS3;
        int viTri=0;
        System.out.println("nhap vao chuoi s1");
        chuoiS1 = nhapChuoi();
        System.out.println("nhap vao chuoi s2");
        chuoiS2 = nhapChuoi();
        System.out.println("nhap vao chuoi s3");
        chuoiS3 = nhapChuoi();
        System.out.println("nhap vao vi tri");
        viTri=Integer.parseInt(nhapChuoi().toString());
        System.out.println("chieu dai chuoi s1: "+chuoiS1.length());
        System.out.println("chieu dai chuoi s2: "+chuoiS2.length());
        System.out.println("chieu dai chuoi s3: "+chuoiS3.length());
        boolean soSanh=chuoiS1.equals(chuoiS2);
         System.out.println("s1 va s2 "+soSanh);
        if(chuoiS1.toString() == null ? chuoiS2.toString() == null : chuoiS1.toString().equals(chuoiS2.toString()))
        {
            System.out.println("s1 va s2 giong nhau");
        }
        else {
            System.out.println("s1 khac s2");
        }
        chuoiS1.append(chuoiS2);
        System.out.println("s1 sau khi noi them s2: "+chuoiS1);
        int viTriXH=chuoiS1.indexOf(chuoiS3.toString());
        System.out.println("vi tri xuat hien cua s3 trong chuoi s1: "+viTriXH);
        String chuoiS4=chuoiS1.substring(viTri);
        System.out.println("chuoi s4: "+chuoiS4);
        

    }

    static StringBuilder nhapChuoi() throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        StringBuilder chuoiS = new StringBuilder(input.readLine().toString());
        return chuoiS;
    }

}
