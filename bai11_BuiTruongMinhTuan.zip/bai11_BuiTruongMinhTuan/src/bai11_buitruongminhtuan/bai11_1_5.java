/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

import java.util.Iterator;

/**
 *
 * @author hocvien
 */
public class bai11_1_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        hinhA();
        System.out.println("hinh A");
        hinhB();
        System.out.println("hinh B");
        hinhC();
        System.out.println("hinh C");
        hinhD();
        System.out.println("hinh D");
        hinhE();
        System.out.println("hinh E");
        hinhF();
        System.out.println("hinh F");
          hinhG();
        System.out.println("hinh G");
         hinhH();
        System.out.println("hinh H");
         hinhI();
        System.out.println("hinh I");
        
    }
    static void hinhA()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i >= j) {
                    maTran1[i][j] = '#';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhB()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i + j<8) {
                    maTran1[i][j] = '#';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j <8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhC()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i>j) {
                    maTran1[i][j] = ' ';
                }
                else{
                    maTran1[i][j] = '#';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhD()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i+j<7) {
                    maTran1[i][j] = ' ';
                }
                else{
                    maTran1[i][j] = '#';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhE()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i==0||j==0||i==7||j==7) {
                    maTran1[i][j] = '#';
                }
                else{
                    maTran1[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhF()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i==0||i==7||i==j) {
                    maTran1[i][j] = '#';
                }
                else{
                    maTran1[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhG()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i==0||i==7||i+j==7) {
                    maTran1[i][j] = '#';
                }
                else{
                    maTran1[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhH()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i==0||i==7||i+j==7||i==j) {
                    maTran1[i][j] = '#';
                }
                else{
                    maTran1[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
    static void hinhI()
    {
        char[][] maTran1 = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i==0||i==7||i+j==7||i==j||j==0||j==7) {
                    maTran1[i][j] = '#';
                }
                else{
                    maTran1[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 System.out.print(maTran1[i][j]+" ");       
            }
            System.out.println();
        }
    }
}
