/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Array;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class bai11_1_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap so duong n");
        int soDuong = Integer.parseInt(input.readLine());
        String[] mangTen = new String[soDuong];
        int soNguoi = 1;
        for (String string : mangTen) {
            System.out.println("nhap ten nguoi dung: " + soNguoi);
            string = input.readLine();
            mangTen[soNguoi - 1] = string;
            soNguoi++;
        }
        soNguoi = 1;
        for (String string : mangTen) {
            System.out.println(" nguoi dung: " + soNguoi + " " + string);
            soNguoi++;
        }

        System.out.println("nhap ten nguoi dung can tim kiem: ");
        String tenTimKiem = input.readLine();
        soNguoi = 0;
        boolean kt = false;
        for (String string : mangTen) {
            if (tenTimKiem.equalsIgnoreCase(string)) {
                System.out.println("tim thay ten nguoi dung tai vi tri: " + soNguoi);
                kt = true;
                break;
            }
            soNguoi++;
        }
        if (!kt) {
            System.out.println("khong tim thay ten nguoi dung");
        }
        System.out.println("ten nguoi dung co chua ki tu (n)");
        for (String string : mangTen) {
            for (int i = 0; i < string.length(); i++) {
                char kiTu = string.charAt(i);
                if (kiTu == 'n') {
                    System.out.println(string);
                    break;
                }
            }
        }
        Arrays.sort(mangTen);
        soNguoi = 1;
        for (String string : mangTen) {
            System.out.println(" nguoi dung: " + soNguoi + " " + string);
            soNguoi++;
        }
    }

}
