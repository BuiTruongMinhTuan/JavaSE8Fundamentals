/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_buitruongminhtuan;

/**
 *
 * @author hocvien
 */
public class bai11_1_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String chuoiS="";
        StringBuilder chuoiSB=new StringBuilder(10000);
        long thoiGianS=System.currentTimeMillis();
        System.out.println("Thoi gian bat dau"+thoiGianS);
        for(int i=0;i<10000;i++)
        {
            chuoiS+=Integer.toString(i)+" ";
        }
        long thoiGianS1=System.currentTimeMillis();
        System.out.println("Thoi gian ket thuc"+thoiGianS1);
        System.out.println("TG thuc hien"+(thoiGianS1-thoiGianS));
        
        long thoiGianSB=System.currentTimeMillis();
        System.out.println("Thoi gian bat dau"+thoiGianSB);
        for(int i=0;i<10000;i++)
        {
            chuoiSB.append(i+" ");
        }
        long thoiGianSB1 = System.currentTimeMillis();
        System.out.println("Thoi gian ket thuc" + thoiGianSB1);
        System.out.println("TG thuc hien" + (thoiGianSB1 - thoiGianSB));
    }
    
}
