/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        
        float soKw;
        float thanhTien=0f;
       
        System.out.println("nhap so kw (>=0)");
        soKw= Float.parseFloat(input.readLine());
        
            if(soKw<=50f)
            {
                thanhTien=soKw*1388f;
            }
            else  if(soKw<=100f)
            {
                thanhTien=50*1388f;
                thanhTien+=(soKw-50)*1433f;
            }
            else if(soKw<=200f)
            {
                thanhTien=50*1388f;
                thanhTien+=50*1433f;
                thanhTien+=(soKw-100)*1660f;
            }
            else if(soKw<=300f)
            {
                thanhTien=50*1388f;
                thanhTien+=50*1433f;
                thanhTien+=100*1660f;
                thanhTien+=(soKw-200)*2082f;
            }
            else if(soKw<=400f)
            {
                thanhTien=50*1388f;
                thanhTien+=50*1433f;
                thanhTien+=100*1660f;
                thanhTien+=100*2082f;
                thanhTien+=(soKw-300)*2324f;
            }
            else
            {
                thanhTien=50*1388f;
                thanhTien+=50*1433f;
                thanhTien+=100*1660f;
                thanhTien+=100*2082f;
                thanhTien+=100*2324f;
                thanhTien+=(soKw-400)*2399f;
            }
            
        
         System.out.println("thanh tien: "+thanhTien);
    }
    
}
