/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import jdk.nashorn.internal.parser.TokenType;

/**
 *
 * @author hocvien
 */
public class bai4_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap loai phong 1-8");
        int loaiPhong=Integer.parseInt(input.readLine());
        System.out.println("so dem o:");
        int soDem=Integer.parseInt(input.readLine());
        
        switch (loaiPhong)
        {
            case 1:
                tinhTien(soDem,1260000);
                break;
            case 2:
                tinhTien(soDem,1550000);
                break;
            case 3:
            case 4:
                tinhTien(soDem,1830000);
                break;
            case 5:
            case 6:
                tinhTien(soDem,2120000);
                break;
            case 7:
                tinhTien(soDem,2540000);
                break;
            case 8:
                tinhTien(soDem,4800000);
                break;
        }
        
        
    }
    
   static void tinhTien(int soDem,int loaiPhong)
    {
        float tongTien = 0;
        if(soDem<=1)
        {
            tongTien=soDem*loaiPhong;
        }
        else if(soDem<=3)
        {
            tongTien=soDem*(loaiPhong*0.75f);
            
        }
        else
        {
            tongTien=soDem*(loaiPhong*0.7f);
        }
        System.out.println("Thanhtien:"+ tongTien);
    }
    
}
