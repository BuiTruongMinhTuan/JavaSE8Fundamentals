/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai4_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
        float soTienGiamTru=9000000*12f;
        float soTienThue=0;
        float soTienChiuThue=0;
        float tongSoThuNhap=0;
        int muc1=60000000;
        int muc2=120000000;
        int muc3=216000000;
        int muc4=384000000;
        int muc5=624000000;
        int muc6=960000000;
       
        System.out.println("Ma so thue:");
        int maSoThue=Integer.parseInt(input.readLine());
        System.out.println("Ho va ten doi tuong tuong nguoi nop:");
        String name=input.readLine();
        System.out.println("Tong so thu nhap trong nam:");
        tongSoThuNhap=Integer.parseInt(input.readLine());
        System.out.println("So nguoi phu thuoc:");
        int soNguoiPhuThuoc=Integer.parseInt(input.readLine());
        
        soTienGiamTru+=soNguoiPhuThuoc*3600000*12f;
        soTienChiuThue=tongSoThuNhap-soTienGiamTru;
        if(soTienChiuThue<=muc1)
        {
             soTienThue=soTienChiuThue*0.05f;
        }
        else if(soTienChiuThue<muc2)
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
        }
        else if(soTienChiuThue<=muc3)
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
            soTienThue+=(soTienChiuThue-muc2)*0.15f;
        }
        else if(soTienChiuThue<=muc4)
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
            soTienThue+=(soTienChiuThue-muc2)*0.15f;
            soTienThue+=(soTienChiuThue-muc3)*0.2f;
        }
        else if(soTienChiuThue<=muc5)
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
            soTienThue+=(soTienChiuThue-muc2)*0.15f;
            soTienThue+=(soTienChiuThue-muc3)*0.2f;
            soTienThue+=(soTienChiuThue-muc4)*0.25f;
        }
        else if(soTienChiuThue<=muc6)
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
            soTienThue+=(soTienChiuThue-muc2)*0.15f;
            soTienThue+=(soTienChiuThue-muc3)*0.2f;
            soTienThue+=(soTienChiuThue-muc4)*0.25f;
            soTienThue+=(soTienChiuThue-muc5)*0.3f;
        }
        else
        {
            soTienThue=muc1*0.05f;
            soTienThue+=(soTienChiuThue-muc1)*0.1f;
            soTienThue+=(soTienChiuThue-muc2)*0.15f;
            soTienThue+=(soTienChiuThue-muc3)*0.2f;
            soTienThue+=(soTienChiuThue-muc4)*0.25f;
            soTienThue+=(soTienChiuThue-muc5)*0.3f; 
            soTienThue+=(soTienChiuThue-muc5)*0.35f; 
        }
       
        if(soTienChiuThue<0)
        {
            soTienChiuThue=0;
        }
        
        System.out.println("--Ket qua:  -------------");
        System.out.println("so tien giam tru: "+String.format("%.0f", soTienGiamTru));
        System.out.println("so tien chiu thue: "+String.format("%.0f", soTienChiuThue));
        System.out.println("so tien phai nop: "+String.format("%.0f", soTienThue));
    }
    
}
