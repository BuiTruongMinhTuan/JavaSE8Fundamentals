/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4_BuiTruongMinhTuan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        int soLonNhat=0;
        int soNhoNhat=0;
        System.out.println("nhap vao a:");
        int a =Integer.parseInt(input.readLine());
        soLonNhat=a;
        soNhoNhat=a;
        System.out.println("nhap vao b:");
        int b =Integer.parseInt(input.readLine());
        soLonNhat=Math.max(b, soLonNhat);
        soNhoNhat=Math.min(b, soNhoNhat);
        System.out.println("nhap vao c:");
        int c =Integer.parseInt(input.readLine());
        soLonNhat=Math.max(c, soLonNhat);
        soNhoNhat=Math.min(c, soNhoNhat);
        System.out.println("nhap vao d:");
        int d =Integer.parseInt(input.readLine());
        soLonNhat=Math.max(d, soLonNhat);
        soNhoNhat=Math.min(d, soNhoNhat);
        
        System.out.println("So lon nhat la:"+soLonNhat);
        System.out.println("So nho nhat la:"+soNhoNhat);
        
       
       
        
                
    }
    
}
