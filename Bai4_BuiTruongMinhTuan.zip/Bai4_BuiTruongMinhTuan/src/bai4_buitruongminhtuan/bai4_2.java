/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import jdk.nashorn.internal.parser.TokenType;

/**
 *
 * @author hocvien
 */
public class bai4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        int loaiXe;
        float soKm;
        float thanhTien=0f;
        System.out.println("nhap vao loai xe (4 hoac 7:");
        loaiXe=Integer.parseInt(input.readLine());
        System.out.println("nhap so km (>=0)");
        soKm= Float.parseFloat(input.readLine());
        
        if(loaiXe==4)
        {
            if(soKm<0.8f)
            {
                thanhTien=11000f;
            }
            else if(soKm<31f)
            {
                thanhTien=11000f;
                thanhTien+=(soKm-.8f)*16500f;  
            }
            else
            {
                thanhTien=30*16500f;
                thanhTien+=(soKm-30)*12400f; 
            }
        }
        
        if(loaiXe==7)
        {
            if(soKm<0.8f)
            {
                thanhTien=11000f;
            }
            else if(soKm<31f)
            {
                thanhTien=11000f;
                thanhTien+=(soKm-.8f)*17000f; 
            }
            else
            {
                thanhTien=30*17000f;
                thanhTien+=(soKm-30)*14400;
            }
        }
         System.out.println("thanh tien: "+thanhTien);
    }
    
}
