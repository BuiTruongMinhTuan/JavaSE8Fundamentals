/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_buitruongminhtuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai4_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
        float nhietDoDoi=0f;
        System.out.println("ban muon nhap do C hay F");
        String loaiDo=input.readLine();
        System.out.println("nhap nhiet do:"+loaiDo);
        float nhietDo=Float.parseFloat(input.readLine());
        
        
        if(loaiDo.equals("c") || loaiDo.equals("C"))
        {
            nhietDoDoi=9/5f*nhietDo+32;
            System.out.println("ket qua "+nhietDo+" do C thanh "+nhietDoDoi+"do F");
        }
        else if(loaiDo.equals("f") || loaiDo.equals("F"))
        {
            nhietDoDoi=5*(nhietDo-32)/9f;
            System.out.println("ket qua "+nhietDo+" do F thanh "+nhietDoDoi+" do C");
        }
        
        
    }
    
}
